<script src="../common/js/jquery.min.js"></script>
<script src="../common/js/bootstrap.min.js"></script>
<script src="../common/js/validator.js"></script>
<script src="../common/js/jquery.validate.js"></script>
<script src="../common/js/custom.min.js"></script>
<script src="../common/js/multiple-select.js"></script>

<link href="../common/css/bootstrap.min.css" rel="stylesheet">
<link href="../common/css/font-awesome.min.css" rel="stylesheet">
<link href="../common/css/custom.min.css" rel="stylesheet">	 
<link href="../common/css/multiple-select.css" rel="stylesheet"/>


<style>
select.error { background-color:#ffa8a8; border: 1px dotted red; float:left;   }
input.error{ background-color:#ffa8a8; border: 1px dotted red; float:left; }
textarea.error{ background-color:#ffa8a8; border: 1px dotted red; vertical-align:top; float:left; }
</style>
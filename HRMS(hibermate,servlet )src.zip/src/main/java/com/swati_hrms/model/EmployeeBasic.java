package com.swati_hrms.model;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="employee_basic")
public class EmployeeBasic {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "scale_name")
    private String scaleName;

    @Column(name = "scale_value")
    private Double scaleValue;

    @Column(name = "calculation_type")
    private String calculationType;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_date")
    private Date createdDate = new Date();
    
    @Column(name = "created_by")
    private String createdBy;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "update_date")
    private Date updatedDate;
    
    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "suspended_status")
	private int suspendedStatus = 0; // set initial state to 0 (active)

	public EmployeeBasic() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeBasic(long id, EmployeePersonalDetails employeePersonalDetails, String scaleName, Double scaleValue,
			String calculationType, Date createdDate, String createdBy, Date updatedDate, String updatedBy,
			int suspendedStatus) {
		super();
		this.id = id;
		this.scaleName = scaleName;
		this.scaleValue = scaleValue;
		this.calculationType = calculationType;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.updatedDate = updatedDate;
		this.updatedBy = updatedBy;
		this.suspendedStatus = suspendedStatus;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getScaleName() {
		return scaleName;
	}

	public void setScaleName(String scaleName) {
		this.scaleName = scaleName;
	}

	public Double getScaleValue() {
		return scaleValue;
	}

	public void setScaleValue(Double scaleValue) {
		this.scaleValue = scaleValue;
	}

	public String getCalculationType() {
		return calculationType;
	}

	public void setCalculationType(String calculationType) {
		this.calculationType = calculationType;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}
    
}

package com.swati_hrms.model;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="documents")
public class Documents {
  
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
	@Column(name="doc_name")
	private String docName;
	
	@Column(name = "suspendend_status")
	private int suspendedStatus = 0; //set initial state to 0(active)

	@Column(name = "created_by")
	private String createdBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate = new Date();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Documents(int id, String docName, int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.docName = docName;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public Documents() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

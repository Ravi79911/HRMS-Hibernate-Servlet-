package com.swati_hrms.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "add_employee_payroll")
public class AddEmployeePayroll {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Version
	private Integer version;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
	private EmployeePersonalDetails employeePersonalDetails;

	@ManyToMany
	@JoinTable(name = "payroll_basic", joinColumns = @JoinColumn(name = "payroll_id"), inverseJoinColumns = @JoinColumn(name = "basic_id"))
	private Set<EmployeeBasic> basics = new HashSet<>();

	@ManyToMany
	@JoinTable(name = "payroll_allowance", joinColumns = @JoinColumn(name = "payroll_id"), inverseJoinColumns = @JoinColumn(name = "allowance_id"))
	private Set<EmployeeAllowance> allowances = new HashSet<>();

	@ManyToMany
	@JoinTable(name = "payroll_deduction", joinColumns = @JoinColumn(name = "payroll_id"), inverseJoinColumns = @JoinColumn(name = "deduction_id"))
	private Set<EmployeeDeduction> deductions = new HashSet<>();

	@Column(name = "suspended_status")
	private int suspendedStatus = 0; // set initial state to 0 (active)

	@Column(name = "created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate = new Date();

	public AddEmployeePayroll() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AddEmployeePayroll(long id, Integer version, EmployeePersonalDetails employeePersonalDetails,
			Set<EmployeeBasic> basics, Set<EmployeeAllowance> allowances, Set<EmployeeDeduction> deductions,
			int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.version = version;
		this.employeePersonalDetails = employeePersonalDetails;
		this.basics = basics;
		this.allowances = allowances;
		this.deductions = deductions;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public EmployeePersonalDetails getEmployeePersonalDetails() {
		return employeePersonalDetails;
	}

	public void setEmployeePersonalDetails(EmployeePersonalDetails employeePersonalDetails) {
		this.employeePersonalDetails = employeePersonalDetails;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Set<EmployeeBasic> getBasics() {
		return basics;
	}

	public void setBasics(Set<EmployeeBasic> basics) {
		this.basics = basics;
	}

	public Set<EmployeeAllowance> getAllowances() {
		return allowances;
	}

	public void setAllowances(Set<EmployeeAllowance> allowances) {
		this.allowances = allowances;
	}

	public Set<EmployeeDeduction> getDeductions() {
		return deductions;
	}

	public void setDeductions(Set<EmployeeDeduction> deductions) {
		this.deductions = deductions;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}

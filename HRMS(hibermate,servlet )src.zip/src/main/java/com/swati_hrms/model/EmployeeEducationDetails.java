package com.swati_hrms.model;

import java.util.Date;

import javax.persistence.*;

public class EmployeeEducationDetails {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
     private int id;
	
	@Column(name = "emp_master_id")
    private int empMasterId;
	
	@Column(name = "emp_master_id")
	private String degree;
	
	@Column(name = "stream_cource")
	private String streamCourse;
	
	@Column(name = "university_board")
	private String universityBoard;
	
	@Column(name = "passing_year")
	private String passingYear;
	
	@Column(name = "cgpa_percentage")
	private String cgpaPercentage;
	
	@Column(name = "suspendend_status")
 	private int suspendedStatus = 0; //set initial state to 0(active)

 	@Column(name = "created_by")
 	private String createdBy;

 	@Temporal(TemporalType.TIMESTAMP)
 	@Column(name = "created_date")
 	private Date createdDate = new Date();

	public EmployeeEducationDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeEducationDetails(int id, int empMasterId, String degree, String streamCourse, String universityBoard,
			String passingYear, String cgpaPercentage, int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.empMasterId = empMasterId;
		this.degree = degree;
		this.streamCourse = streamCourse;
		this.universityBoard = universityBoard;
		this.passingYear = passingYear;
		this.cgpaPercentage = cgpaPercentage;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEmpMasterId() {
		return empMasterId;
	}

	public void setEmpMasterId(int empMasterId) {
		this.empMasterId = empMasterId;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public String getStreamCourse() {
		return streamCourse;
	}

	public void setStreamCourse(String streamCourse) {
		this.streamCourse = streamCourse;
	}

	public String getUniversityBoard() {
		return universityBoard;
	}

	public void setUniversityBoard(String universityBoard) {
		this.universityBoard = universityBoard;
	}

	public String getPassingYear() {
		return passingYear;
	}

	public void setPassingYear(String passingYear) {
		this.passingYear = passingYear;
	}

	public String getCgpaPercentage() {
		return cgpaPercentage;
	}

	public void setCgpaPercentage(String cgpaPercentage) {
		this.cgpaPercentage = cgpaPercentage;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	

}

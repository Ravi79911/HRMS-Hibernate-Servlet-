package com.swati_hrms.model;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "add_key_skill")
public class AddKeySkill {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
	private EmployeePersonalDetails employeePersonalDetails;
    
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "key_skills_id", referencedColumnName = "id")
	private KeySkills keySkills;
	
	@Column(name="skill_name")
	private String keySkillName;

	@Column(name = "exp_months")
	private long expMonths;

	@Column(name = "suspended_status")
	private int suspendedStatus = 0; // set initial state to 0 (active)

	@Column(name = "created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate = new Date();

	// Default constructor (required by JPA)
	public AddKeySkill() {
		super();
		// TODO Auto-generated constructor stub
	}

	// Parameterized constructor for convenience
	public AddKeySkill(int id, EmployeePersonalDetails employeePersonalDetails, KeySkills keySkills,
			String keySkillName, long expMonths, int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.employeePersonalDetails = employeePersonalDetails;
		this.keySkills = keySkills;
		this.keySkillName = keySkillName;
		this.expMonths = expMonths;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}


	// Getters and setters for all fields
	public int getId() {
		return id;
	}

	
	public void setId(int id) {
		this.id = id;
	}

	public EmployeePersonalDetails getEmployeePersonalDetails() {
		return employeePersonalDetails;
	}

	public void setEmployeePersonalDetails(EmployeePersonalDetails employeePersonalDetails) {
		this.employeePersonalDetails = employeePersonalDetails;
	}

	

	public KeySkills getKeySkills() {
		return keySkills;
	}

	public void setKeySkills(KeySkills keySkills) {
		this.keySkills = keySkills;
	}

	public String getKeySkillName() {
		return keySkillName;
	}

	public void setKeySkillName(String keySkillName) {
		this.keySkillName = keySkillName;
	}

	public long getExpMonths() {
		return expMonths;
	}

	public void setExpMonths(long expMonths) {
		this.expMonths = expMonths;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
}

package com.swati_hrms.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "employee_personal_details")
public class EmployeePersonalDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "employee_code", nullable = false)
	private String employee_code;

	@Column(name = "employee_first_name", nullable = false)
	private String employeeFirstName;

	@Column(name = "employee_last_name", nullable = false)
	private String employeeLastName;

	@Column(name = "employee_father_name")
	private String employeeFatherName;

	@Column(name = "employee_mothers_name")
	private String employeeMotherName;

	@Column(name = "DOB", nullable = false)
	private LocalDate DOB;

	@Column(name = "gender", nullable = false)
	private String gender;

	@Column(name = "mob_no", nullable = false)
	private String mobileNo;

	@Column(name = "email", nullable = false)
	private String email;

	@Column(name = "guardian_mob_no", nullable = false)
	private String guardianMobNo;

	@Column(name = "aadhaar_no", nullable = false)
	private String aadhaarNo;

	@Column(name = "pan_no", nullable = false)
	private String panNo;

	@Column(name = "local_address", nullable = false)
	private String localAddress;

	@Column(name = "local_pin_code", nullable = false)
	private String localPinCode;

	@Column(name = "local_city", nullable = false)
	private String localCity;

	@Column(name = "local_state", nullable = false)
	private String localState;

	@Column(name = "local_country", nullable = false)
	private String localCountry;

	@Column(name = "permanent_address", nullable = false)
	private String permanentAddress;

	@Column(name = "permanent_pin_code", nullable = false)
	private String permanentPinCode;

	@Column(name = "permanent_city", nullable = false)
	private String permanentCity;

	@Column(name = "permanent_state", nullable = false)
	private String permanentState;

	@Column(name = "permanent_country", nullable = false)
	private String permanentCountry;

	@Column(name = "suspendend_status")
	private int suspendedStatus;

	@Column(name = "created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate = new Date();

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<AddDocuments> documents = new ArrayList<>();

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<AddKeySkill> keySkills = new ArrayList<>();

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<EmpEducationDetails> educationDetails = new ArrayList<>();

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<EmployeeDependent> dependents = new ArrayList<>();

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<EmployeeExperienceDetails> experienceDetails = new ArrayList<>();

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<EmpJoiningDetails> empJoiningDetails = new ArrayList<>();

	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<UserRegistration> userRegisteration = new ArrayList<>();
	
	@OneToMany(mappedBy = "employeePersonalDetails", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<AddEmployeePayroll> employeePayroll = new ArrayList<>();

	// constructor
	public EmployeePersonalDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeePersonalDetails(int id, String employee_code, String employeeFirstName, String employeeLastName,
			String employeeFatherName, String employeeMotherName, LocalDate DOB, String gender, String mobileNo,
			String email, String guardianMobNo, String aadhaarNo, String panNo, String localAddress,
			String localPinCode, String localCity, String localState, String localCountry, String permanentAddress,
			String permanentPinCode, String permanentCity, String permanentState, String permanentCountry,
			int suspendedStatus, String createdBy, Date createdDate, List<AddDocuments> documents,
			List<AddKeySkill> keySkills, List<EmpEducationDetails> educationDetails, List<EmployeeDependent> dependents,
			List<EmployeeExperienceDetails> experienceDetails, List<UserRegistration> userRegisteration,
			List<EmpJoiningDetails> empJoiningDetails, List<AddEmployeePayroll> employeePayroll) {
		super();
		this.id = id;
		this.employee_code = employee_code;
		this.employeeFirstName = employeeFirstName;
		this.employeeLastName = employeeLastName;
		this.employeeFatherName = employeeFatherName;
		this.employeeMotherName = employeeMotherName;
		this.DOB = DOB;
		this.gender = gender;
		this.mobileNo = mobileNo;
		this.email = email;
		this.guardianMobNo = guardianMobNo;
		this.aadhaarNo = aadhaarNo;
		this.panNo = panNo;
		this.localAddress = localAddress;
		this.localPinCode = localPinCode;
		this.localCity = localCity;
		this.localState = localState;
		this.localCountry = localCountry;
		this.permanentAddress = permanentAddress;
		this.permanentPinCode = permanentPinCode;
		this.permanentCity = permanentCity;
		this.permanentState = permanentState;
		this.permanentCountry = permanentCountry;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.documents = documents;
		this.keySkills = keySkills;
		this.educationDetails = educationDetails;
		this.dependents = dependents;
		this.experienceDetails = experienceDetails;
		this.userRegisteration = userRegisteration;
		this.empJoiningDetails = empJoiningDetails;
		this.employeePayroll = employeePayroll;
	}

//getters & setters

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmployee_code() {
		return employee_code;
	}

	public void setEmployee_code(String employee_code) {
		this.employee_code = employee_code;
	}

	public String getEmployeeFirstName() {
		return employeeFirstName;
	}

	public void setEmployeeFirstName(String employeeFirstName) {
		this.employeeFirstName = employeeFirstName;
	}

	public String getEmployeeLastName() {
		return employeeLastName;
	}

	public void setEmployeeLastName(String employeeLastName) {
		this.employeeLastName = employeeLastName;
	}

	public String getEmployeeFatherName() {
		return employeeFatherName;
	}

	public void setEmployeeFatherName(String employeeFatherName) {
		this.employeeFatherName = employeeFatherName;
	}

	public String getEmployeeMotherName() {
		return employeeMotherName;
	}

	public void setEmployeeMotherName(String employeeMotherName) {
		this.employeeMotherName = employeeMotherName;
	}

	public LocalDate getDOB() {
		return DOB;
	}

	public void setDOB(LocalDate dOB) {
		DOB = dOB;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGuardianMobNo() {
		return guardianMobNo;
	}

	public void setGuardianMobNo(String guardianMobNo) {
		this.guardianMobNo = guardianMobNo;
	}

	public String getAadhaarNo() {
		return aadhaarNo;
	}

	public void setAadhaarNo(String aadhaarNo) {
		this.aadhaarNo = aadhaarNo;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public String getLocalAddress() {
		return localAddress;
	}

	public void setLocalAddress(String localAddress) {
		this.localAddress = localAddress;
	}

	public String getLocalPinCode() {
		return localPinCode;
	}

	public void setLocalPinCode(String localPinCode) {
		this.localPinCode = localPinCode;
	}

	public String getLocalCity() {
		return localCity;
	}

	public void setLocalCity(String localCity) {
		this.localCity = localCity;
	}

	public String getLocalState() {
		return localState;
	}

	public void setLocalState(String localState) {
		this.localState = localState;
	}

	public String getLocalCountry() {
		return localCountry;
	}

	public void setLocalCountry(String localCountry) {
		this.localCountry = localCountry;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getPermanentPinCode() {
		return permanentPinCode;
	}

	public void setPermanentPinCode(String permanentPinCode) {
		this.permanentPinCode = permanentPinCode;
	}

	public String getPermanentCity() {
		return permanentCity;
	}

	public void setPermanentCity(String permanentCity) {
		this.permanentCity = permanentCity;
	}

	public String getPermanentState() {
		return permanentState;
	}

	public void setPermanentState(String permanentState) {
		this.permanentState = permanentState;
	}

	public String getPermanentCountry() {
		return permanentCountry;
	}

	public void setPermanentCountry(String permanentCountry) {
		this.permanentCountry = permanentCountry;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public List<AddDocuments> getDocuments() {
		return documents;
	}

	public void setDocuments(List<AddDocuments> documents) {
		this.documents = documents;
	}

	public List<AddKeySkill> getKeySkills() {
		return keySkills;
	}

	public void setKeySkills(List<AddKeySkill> keySkills) {
		this.keySkills = keySkills;
	}

	public List<EmpEducationDetails> getEducationDetails() {
		return educationDetails;
	}

	public void setEducationDetails(List<EmpEducationDetails> educationDetails) {
		this.educationDetails = educationDetails;
	}

	public List<EmployeeDependent> getDependents() {
		return dependents;
	}

	public void setDependents(List<EmployeeDependent> dependents) {
		this.dependents = dependents;
	}

	public List<EmployeeExperienceDetails> getExperienceDetails() {
		return experienceDetails;
	}

	public void setExperienceDetails(List<EmployeeExperienceDetails> experienceDetails) {
		this.experienceDetails = experienceDetails;
	}

	public List<EmpJoiningDetails> getEmpJoiningDetails() {
		return empJoiningDetails;
	}

	public void setEmpJoiningDetails(List<EmpJoiningDetails> empJoiningDetails) {
		this.empJoiningDetails = empJoiningDetails;
	}

	public List<UserRegistration> getUserRegisteration() {
		return userRegisteration;
	}

	public void setUserRegisteration(List<UserRegistration> userRegisteration) {
		this.userRegisteration = userRegisteration;
	}
	
	public List<AddEmployeePayroll> getEmployeePayroll() {
		return employeePayroll;
	}

	public void setEmployeePayroll(List<AddEmployeePayroll> employeePayroll) {
		this.employeePayroll = employeePayroll;
	}

	// Method to get profile image filename
	public String getProfileImageFilename() {
		for (AddDocuments doc : documents) {
			return doc.getFileName();
		}
		return null; // Return null if no profile image is found
	}

}

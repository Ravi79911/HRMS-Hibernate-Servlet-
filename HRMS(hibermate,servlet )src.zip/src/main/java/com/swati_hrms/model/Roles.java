package com.swati_hrms.model;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="roles")
public class Roles {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "role_name")
	private String roleName;
	
	@Column(name = "suspendend_status")
	private int suspendedStatus = 0; //set initial state to 0(active)

	@Column(name = "created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate = new Date();

	public Roles() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Roles(int id, String roleName, int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.roleName = roleName;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	
}

package com.swati_hrms.model;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "emp_education_details")
public class EmpEducationDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
	private EmployeePersonalDetails employeePersonalDetails;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "degree_id", referencedColumnName = "id")
	private Degree degree; // Changed to Degree object

	@Column(name = "degree_name")
	private String degreeName;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "stream_cource_id", referencedColumnName = "id")
	private Streams streamCourse; // Changed to Streams object

	@Column(name = "degree_course_name")
	private String streamCourseName;

	@Column(name = "university_board")
	private String universityBoard;

	@Column(name = "passing_year")
	private String passingYear;

	@Column(name = "cgpa_percentage")
	private String cgpaPercentage;

	@Column(name = "suspendend_status")
	private int suspendedStatus = 0; // set initial state to 0(active)

	@Column(name = "created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate = new Date();

	public EmpEducationDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmpEducationDetails(int id, EmployeePersonalDetails employeePersonalDetails, Degree degree,
			Streams streamCourse, String universityBoard, String passingYear, String cgpaPercentage,
			int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.employeePersonalDetails = employeePersonalDetails;
		this.degree = degree;
		this.streamCourse = streamCourse;
		this.universityBoard = universityBoard;
		this.passingYear = passingYear;
		this.cgpaPercentage = cgpaPercentage;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public EmployeePersonalDetails getEmployeePersonalDetails() {
		return employeePersonalDetails;
	}

	public void setEmployeePersonalDetails(EmployeePersonalDetails employeePersonalDetails) {
		this.employeePersonalDetails = employeePersonalDetails;
	}

	public Degree getDegree() {
		return degree;
	}

	public void setDegree(Degree degree) {
		this.degree = degree;
	}

	public String getDegreeName() {
		return degreeName;
	}

	public void setDegreeName(String degreeName) {
		this.degreeName = degreeName;
	}

	public Streams getStreamCourse() {
		return streamCourse;
	}

	public void setStreamCourse(Streams streamCourse) {
		this.streamCourse = streamCourse;
	}

	public String getStreamCourseName() {
		return streamCourseName;
	}

	public void setStreamCourseName(String streamCourseName) {
		this.streamCourseName = streamCourseName;
	}

	public String getUniversityBoard() {
		return universityBoard;
	}

	public void setUniversityBoard(String universityBoard) {
		this.universityBoard = universityBoard;
	}

	public String getPassingYear() {
		return passingYear;
	}

	public void setPassingYear(String passingYear) {
		this.passingYear = passingYear;
	}

	public String getCgpaPercentage() {
		return cgpaPercentage;
	}

	public void setCgpaPercentage(String cgpaPercentage) {
		this.cgpaPercentage = cgpaPercentage;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}

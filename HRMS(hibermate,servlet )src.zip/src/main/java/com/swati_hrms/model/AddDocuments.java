package com.swati_hrms.model;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "add_documents")
public class AddDocuments {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
	private EmployeePersonalDetails employeePersonalDetails;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "doc_id", referencedColumnName = "id")
	private Documents documents;

	@Column(name = "doc_name")
	private String docName;

	@Column(name = "file_Name")
	private String fileName;

	@Column(name = "suspended_status")
	private int suspendedStatus = 0; // set initial state to 0 (active)

	@Column(name = "created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate = new Date();

	public AddDocuments() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AddDocuments(int id, EmployeePersonalDetails employeePersonalDetails, Documents documents, String docName,
			String fileName, int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.employeePersonalDetails = employeePersonalDetails;
		this.documents = documents;
		this.docName = docName;
		this.fileName = fileName;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public EmployeePersonalDetails getEmployeePersonalDetails() {
		return employeePersonalDetails;
	}

	public void setEmployeePersonalDetails(EmployeePersonalDetails employeePersonalDetails) {
		this.employeePersonalDetails = employeePersonalDetails;
	}

	public Documents getDocuments() {
		return documents;
	}

	public void setDocuments(Documents documents) {
		this.documents = documents;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}

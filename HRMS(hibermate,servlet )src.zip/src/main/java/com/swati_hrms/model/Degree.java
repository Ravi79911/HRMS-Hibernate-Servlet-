package com.swati_hrms.model;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="degrees")
public class Degree {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "degree")
	private String degree;
	
	@Column(name = "suspendend_status")
	private int suspendedStatus = 0; //set initial state to 0(active)

	@Column(name = "created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate = new Date();

	// getters & setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	// constructor
	public Degree() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Degree(int id, String degree, int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.degree = degree;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}


	


}

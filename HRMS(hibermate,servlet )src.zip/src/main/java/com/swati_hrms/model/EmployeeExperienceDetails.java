package com.swati_hrms.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "employee_experience_details")
public class EmployeeExperienceDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "emp_master_id", referencedColumnName = "id", nullable = false)
	private EmployeePersonalDetails employeePersonalDetails;

	@Column(name = "comp_name")
	private String companyName;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "designation_id", referencedColumnName = "id")
	private Designation designation;

	@Column(name = "designation_name")
	private String designationName;

	@Column(name = "from_date")
	private LocalDate fromDate;

	@Column(name = "upto_date")
	private LocalDate uptoDate;

	@Column(name = "project_details")
	private String projectDetails;

	@Column(name = "suspendend_status")
	private int suspendedStatus = 0; // set initial state to 0(active)

	@Column(name = "created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate = new Date();

	public EmployeeExperienceDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeExperienceDetails(int id, EmployeePersonalDetails employeePersonalDetails, String companyName,
			Designation designation, String designationName, LocalDate fromDate, LocalDate uptoDate,
			String projectDetails, int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.employeePersonalDetails = employeePersonalDetails;
		this.companyName = companyName;
		this.designation = designation;
		this.designationName = designationName;
		this.fromDate = fromDate;
		this.uptoDate = uptoDate;
		this.projectDetails = projectDetails;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public EmployeePersonalDetails getEmployeePersonalDetails() {
		return employeePersonalDetails;
	}

	public void setEmployeePersonalDetails(EmployeePersonalDetails employeePersonalDetails) {
		this.employeePersonalDetails = employeePersonalDetails;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Designation getDesignation() {
		return designation;
	}

	public void setDesignation(Designation designation) {
		this.designation = designation;
	}

	public String getDesignationName() {
		return designationName;
	}

	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDate getUptoDate() {
		return uptoDate;
	}

	public void setUptoDate(LocalDate uptoDate) {
		this.uptoDate = uptoDate;
	}

	public String getProjectDetails() {
		return projectDetails;
	}

	public void setProjectDetails(String projectDetails) {
		this.projectDetails = projectDetails;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

}

package com.swati_hrms.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="employee_joining_details")
public class EmployeeJoiningDetails {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
    @Column(name = "emp_master_id")
    private int empMasterId;
    
    @Column(name = "joining_date")
    private LocalDate joiningDate;
    
    @Column(name = "designation_id")
    private int designationId;
    
    @Column(name = "department_id")
    private int departmentId;
    
    @Column(name = "location")
    private String location;

	@Column(name = "suspendend_status")
 	private int suspendedStatus = 0; //set initial state to 0(active)

 	@Column(name = "created_by")
 	private String createdBy;

 	@Temporal(TemporalType.TIMESTAMP)
 	@Column(name = "created_date")
 	private Date createdDate = new Date();

	public EmployeeJoiningDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeJoiningDetails(int id, int empMasterId, LocalDate joiningDate, int designationId, int departmentId,
			String location, int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.empMasterId = empMasterId;
		this.joiningDate = joiningDate;
		this.designationId = designationId;
		this.departmentId = departmentId;
		this.location = location;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEmpMasterId() {
		return empMasterId;
	}

	public void setEmpMasterId(int empMasterId) {
		this.empMasterId = empMasterId;
	}

	public LocalDate getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(LocalDate joiningDate) {
		this.joiningDate = joiningDate;
	}

	public int getDesignationId() {
		return designationId;
	}

	public void setDesignationId(int designationId) {
		this.designationId = designationId;
	}

	public int getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
 	

}

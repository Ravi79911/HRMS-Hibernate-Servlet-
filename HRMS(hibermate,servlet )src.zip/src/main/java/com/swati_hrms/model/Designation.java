package com.swati_hrms.model;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "designation")
public class Designation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "designation")
	private String designation;

	@Column(name = "suspendend_status")
	private int suspendedStatus;

	@Column(name = "created_by")
	private String createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_date")
	private Date createdDate = new Date();


	// constructor

	public Designation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Designation(int id, String designation, int suspendedStatus, String createdBy, Date createdDate) {
		super();
		this.id = id;
		this.designation = designation;
		this.suspendedStatus = suspendedStatus;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	// getters & setters
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getSuspendedStatus() {
		return suspendedStatus;
	}

	public void setSuspendedStatus(int suspendedStatus) {
		this.suspendedStatus = suspendedStatus;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}



}

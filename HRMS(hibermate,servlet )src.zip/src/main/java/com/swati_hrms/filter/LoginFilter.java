package com.swati_hrms.filter;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebFilter("/*") // This will apply to all URLs
public class LoginFilter implements Filter {

    public void init(FilterConfig fConfig) throws ServletException {
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        
        // Set cache control headers to prevent caching
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1
        res.setHeader("Pragma", "no-cache"); // HTTP 1.0
        res.setDateHeader("Expires", 0); // Proxies

        // Allow the login page and static resources to be accessed without authentication
        String loginURI = req.getContextPath() + "/login.jsp";
        String loginServlet = req.getContextPath() + "/userlogin";
        String forgotPasswordServlet = req.getContextPath() + "/forgot-password";
        String resetPasswordServlet = req.getContextPath() + "/reset-password";

        boolean loggedIn = (session != null && session.getAttribute("userName") != null);
        boolean loginRequest = req.getRequestURI().equals(loginURI) || req.getRequestURI().equals(loginServlet);
        boolean forgotPasswordRequest = req.getRequestURI().equals(forgotPasswordServlet);
        boolean resetPasswordRequest = req.getRequestURI().equals(resetPasswordServlet);

        if (loggedIn || loginRequest || forgotPasswordRequest || resetPasswordRequest) {
            // Continue to the requested page
            chain.doFilter(request, response);
        } else {
            // Redirect to the login page if not logged in
            res.sendRedirect(req.getContextPath() + "/login.jsp");
        }
    }

    public void destroy() {
    }
}

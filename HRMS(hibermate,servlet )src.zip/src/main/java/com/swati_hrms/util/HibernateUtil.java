package com.swati_hrms.util;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

import com.swati_hrms.model.AddDocuments;
import com.swati_hrms.model.AddEmployeePayroll;
import com.swati_hrms.model.AddKeySkill;
import com.swati_hrms.model.Degree;
import com.swati_hrms.model.Department;
import com.swati_hrms.model.Designation;
import com.swati_hrms.model.Documents;
import com.swati_hrms.model.EmpEducationDetails;
import com.swati_hrms.model.EmpJoiningDetails;
import com.swati_hrms.model.EmployeeAllowance;
import com.swati_hrms.model.EmployeeBasic;
import com.swati_hrms.model.EmployeeDeduction;
import com.swati_hrms.model.EmployeeDependent;
import com.swati_hrms.model.EmployeeExperienceDetails;
import com.swati_hrms.model.EmployeePersonalDetails;
import com.swati_hrms.model.KeySkills;
//import com.swati_hrms.model.PayrollAllowance;
//import com.swati_hrms.model.PayrollBasic;
//import com.swati_hrms.model.PayrollDeduction;
import com.swati_hrms.model.Roles;
import com.swati_hrms.model.Streams;
import com.swati_hrms.model.UserRegistration;

public class HibernateUtil {

    private static SessionFactory sessionFactory;

    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            synchronized (HibernateUtil.class) {
                if (sessionFactory == null) {
                    try {
                        Configuration configuration = new Configuration();

                        // Hibernate settings equivalent to hibernate.cfg.xml's properties
                        Properties settings = new Properties();
                        settings.put(Environment.DRIVER, "org.postgresql.Driver");
//                        settings.put(Environment.URL, "jdbc:postgresql://localhost:5432/swati_industries?useSSL=false&allowPublicKeyRetrieval=true");
//                        settings.put(Environment.USER, "postgres");
//                        settings.put(Environment.PASS, "Babu@2803");
                        settings.put(Environment.URL, "jdbc:postgresql://192.168.29.245:5432/swati_hrms");
                        settings.put(Environment.USER, "postgres");
                        settings.put(Environment.PASS, "admin");
                        settings.put(Environment.DIALECT, "org.hibernate.dialect.PostgreSQLDialect");

                        settings.put(Environment.SHOW_SQL, "true");
//                          settings.put(Environment.FORMAT_SQL, "true");
                        settings.put(Environment.CURRENT_SESSION_CONTEXT_CLASS, "thread");
                        settings.put(Environment.HBM2DDL_AUTO, "update");

                        configuration.setProperties(settings);
                        configuration.addAnnotatedClass(EmployeePersonalDetails.class);
                        configuration.addAnnotatedClass(Department.class);
                        configuration.addAnnotatedClass(Designation.class);
                        configuration.addAnnotatedClass(Degree.class);
                        configuration.addAnnotatedClass(Documents.class);
                        configuration.addAnnotatedClass(KeySkills.class);
                        configuration.addAnnotatedClass(Streams.class);
                        configuration.addAnnotatedClass(AddKeySkill.class);
                        configuration.addAnnotatedClass(EmployeeDependent.class);
                        configuration.addAnnotatedClass(EmpEducationDetails.class);
                        configuration.addAnnotatedClass(EmployeeExperienceDetails.class);
                        configuration.addAnnotatedClass(AddDocuments.class);
                        configuration.addAnnotatedClass(Roles.class);
                        configuration.addAnnotatedClass(UserRegistration.class);
                        configuration.addAnnotatedClass(EmpJoiningDetails.class);
                        configuration.addAnnotatedClass(EmployeeAllowance.class);
                        configuration.addAnnotatedClass(EmployeeDeduction.class);
                        configuration.addAnnotatedClass(EmployeeBasic.class);
                        configuration.addAnnotatedClass(AddEmployeePayroll.class);
//                        configuration.addAnnotatedClass(PayrollBasic.class);
//                        configuration.addAnnotatedClass(PayrollDeduction.class);
//                        configuration.addAnnotatedClass(PayrollAllowance.class);

                        ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
                                .applySettings(configuration.getProperties()).build();

                        sessionFactory = configuration.buildSessionFactory(serviceRegistry);
                    } catch (Exception e) {
                        throw new ExceptionInInitializerError(e);
                    }
                }
            }
        }
        return sessionFactory;
    }
}


package com.swati_hrms.util;

//import java.net.Authenticator;
//import java.net.PasswordAuthentication;
import java.util.Properties;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.Message;
import javax.mail.internet.MimeMessage;

public class EmailUtility {

    // Configure the email server (in this case, Gmail's SMTP server)
    private static final String HOST = "smtp.gmail.com";  // SMTP server for Gmail
    private static final String PORT = "587";  // Port for TLS
    private static final String USERNAME = "csatyam13@gmail.com";  // Replace with your email address
    private static final String PASSWORD = "rhqbhzlbgmsbmtil";  // Replace with your app-specific password

    /**
     * Sends an email using the provided parameters.
     * 
     * @param recipientEmail the email address to send to
     * @param subject the subject of the email
     * @param content the body content of the email
     * @throws AddressException if the email address is invalid
     * @throws MessagingException if there is an error during sending
     */
    public static void sendEmail(String recipientEmail, String subject, String content)
            throws AddressException, MessagingException {
        
        // Set the email server properties
        Properties properties = new Properties();
        properties.put("mail.smtp.host", HOST);
        properties.put("mail.smtp.port", PORT);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");  // Enable TLS
        
        // Get the session object
        Session session = Session.getDefaultInstance(properties, new javax.mail.Authenticator() {
        	protected PasswordAuthentication getPasswordAuthentication() {
        		return new PasswordAuthentication(USERNAME, PASSWORD);
        	}
        });

        try {
            // Create a new email message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME));  // Set the sender's email address
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));  // Set recipient
            message.setSubject(subject);  // Set subject
            message.setText(content);  // Set email body content

            // Send the email
            Transport.send(message);
            System.out.println("Email sent successfully to " + recipientEmail);
        } catch (MessagingException e) {
            throw new RuntimeException("Error while sending email", e);
        }
    }
}

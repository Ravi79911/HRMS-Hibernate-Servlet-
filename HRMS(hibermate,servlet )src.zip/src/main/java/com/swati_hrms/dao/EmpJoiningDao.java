package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.model.EmpJoiningDetails;
import com.swati_hrms.util.HibernateUtil;

public class EmpJoiningDao {
    public void saveEmpJoining(EmpJoiningDetails empJoiningDetails) {
    	Transaction transaction = null;
    	try(Session session = HibernateUtil.getSessionFactory().openSession()){
    		transaction = session.beginTransaction();
    		
    		session.save(empJoiningDetails);
    		transaction.commit();
    	}catch(Exception e) {
    		if(transaction != null) {
    			transaction.rollback();
    		}
    		e.printStackTrace();
    	}
    }
    
    public EmpJoiningDetails getEmpJoiningById(int id) {
    	try(Session session = HibernateUtil.getSessionFactory().openSession()){
    	     return	session.get(EmpJoiningDetails.class, id);
    	}catch(Exception e) {
    		e.printStackTrace();
    		return null;
    	}
    }
    
    public void updateJoiningDetails(EmpJoiningDetails empJoiningDetails) {
    	Transaction transaction = null;
    	try(Session session = HibernateUtil.getSessionFactory().openSession()){
    		transaction = session.beginTransaction();
    		
    		session.update(empJoiningDetails);
    		transaction.commit();
    	}catch(Exception e) {
    		if(transaction != null) {
    			transaction.rollback();
    		}
    		e.printStackTrace();
    	}
    }
    
    public List<EmpJoiningDetails> getAllEmpJoiningDetails(){
    	try(Session session = HibernateUtil.getSessionFactory().openSession()){
    		return session.createQuery("FROM EmpJoiningDetails where suspendedStatus = 0", EmpJoiningDetails.class).list();
    	}catch(Exception e) {
    		e.printStackTrace();
            return null;
    	}
    }
}

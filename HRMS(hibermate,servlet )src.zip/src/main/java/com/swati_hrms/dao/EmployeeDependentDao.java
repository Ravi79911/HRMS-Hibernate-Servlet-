package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.model.EmployeeDependent;
import com.swati_hrms.util.HibernateUtil;

public class EmployeeDependentDao {
	
	public void saveDependent(EmployeeDependent dependent) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.save(dependent);
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public EmployeeDependent getEmployeeDependentById(int id) {
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			return session.get(EmployeeDependent.class, id);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void updateEmployeeDependent(EmployeeDependent dependent) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.update(dependent);
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public List<EmployeeDependent> getAllEmpDependent(){
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			return session.createQuery("FROM EmployeeDependent where suspendedStatus = 0", EmployeeDependent.class).list();
		}catch (Exception e) {
            e.printStackTrace();
            return null;
	    }
	}

}

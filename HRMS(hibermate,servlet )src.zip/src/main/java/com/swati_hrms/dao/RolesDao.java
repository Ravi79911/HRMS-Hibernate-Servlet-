package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.model.Roles;
import com.swati_hrms.util.HibernateUtil;

public class RolesDao {
	
	public void saveRole(Roles role) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.save(role);
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public Roles getRoleById(int id) {
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			return session.get(Roles.class, id);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void updateRole(Roles role) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.update(role);
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public List<Roles> getAllRoles(){
		 try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            return session.createQuery("FROM Roles where suspendedStatus = 0", Roles.class).list();
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	}

}

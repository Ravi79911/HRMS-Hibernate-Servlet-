package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.model.AddKeySkill;
import com.swati_hrms.util.HibernateUtil;

public class AddKeySkillsDao {
   
	public void saveSkill(AddKeySkill addKeySkill) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.save(addKeySkill);
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public AddKeySkill getAddedSkillById(int id) {
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			return session.get(AddKeySkill.class, id);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void updateAddedKeySkill(AddKeySkill addKeySkill) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.update(addKeySkill);
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public List<AddKeySkill> getAllAddedSkill(){
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			return session.createQuery("FROM AddKeySkill where suspendedStatus = 0", AddKeySkill.class).list();
		} catch (Exception e) {
            e.printStackTrace();
            return null;
	  }
   }		
}

package com.swati_hrms.dao;

import java.util.Collections;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.swati_hrms.model.EmployeeBasic;
import com.swati_hrms.util.HibernateUtil;

public class EmployeeBasicDao {
   
	public void saveEmployeeBasic(EmployeeBasic basics) {
		Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            
                session.save(basics);
           
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
	}
	
    public EmployeeBasic getBasicById(long id) {
    	
        try (Session session = HibernateUtil.getSessionFactory().openSession()){
            return session.get(EmployeeBasic.class, id);
        
        } catch (Exception e) {
            e.printStackTrace();
         } 
         return null;
     }
    
    public EmployeeBasic getBasicByScaleNameAndValue(String scaleName, Double scaleValue) {
        EmployeeBasic employeeBasic = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Create a query to search by scaleName and scaleValue
            String hql = "FROM EmployeeBasic WHERE scaleName = :scaleName AND scaleValue = :scaleValue";
            Query<EmployeeBasic> query = session.createQuery(hql, EmployeeBasic.class);
            query.setParameter("scaleName", scaleName);
            query.setParameter("scaleValue", scaleValue);
            
            List<EmployeeBasic> results = query.list();
            if (!results.isEmpty()) {
                employeeBasic = results.get(0); // Assuming you expect only one result
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employeeBasic;
    }
    
    public void updateBasic(EmployeeBasic employeeBasic) {
  	  Transaction transaction = null;
  	  
  	  try (Session session=HibernateUtil.getSessionFactory().openSession()){ 
  		transaction = session.beginTransaction(); 
  	  		session.update(employeeBasic);
  	  	transaction.commit();
  	  		} catch (Exception e) { 
  	  			if (transaction != null) transaction.rollback();
  	  			e.printStackTrace();
  	  			} 
  	   }
    
    public List<EmployeeBasic> getAllBasics(){
    	try(Session session = HibernateUtil.getSessionFactory().openSession()){
    		List<EmployeeBasic> basics = session.createQuery("FROM EmployeeBasic WHERE suspendedStatus = 0", EmployeeBasic.class).list();
	        session.close();
	        return basics;
    	}catch(Exception e) {
    		e.printStackTrace();
    		return null;
    	}
    }
    
    public EmployeeBasic getScaleByName(String scaleName) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Assuming scaleName is unique or you only want the first match
            return session.createQuery("FROM EmployeeBasic WHERE scaleName = :scaleName AND suspendedStatus = 0", EmployeeBasic.class)
                          .setParameter("scaleName", scaleName)
                          .setMaxResults(1) // Ensure only one result is returned
                          .uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void delete(EmployeeBasic basic) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.delete(basic); // Delete the entity
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback(); // Rollback if there is an error
            }
            e.printStackTrace();
        }
    }
    
}

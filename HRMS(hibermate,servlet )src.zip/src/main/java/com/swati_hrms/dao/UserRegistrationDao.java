package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.swati_hrms.model.UserRegistration;
import com.swati_hrms.util.HibernateUtil;

public class UserRegistrationDao {
     
  public void saveUser(UserRegistration user) {
	  Transaction transaction = null;
	  try(Session session = HibernateUtil.getSessionFactory().openSession()){
		  transaction = session.beginTransaction();
		  
		  session.save(user);
		  transaction.commit();
	  }catch(Exception e) {
		  if(transaction != null) {
			  transaction.rollback();
		  }
		  e.printStackTrace();
	  }
  }
  
  public UserRegistration getUserById(int id) {
	  try(Session session = HibernateUtil.getSessionFactory().openSession()){
		  return session.get(UserRegistration.class, id);
	  }catch(Exception e) {
		  e.printStackTrace();
	  }
	  return null;
  }
  
  public void UpdateUser(UserRegistration user) {
	  Transaction transaction = null;
	  try(Session session = HibernateUtil.getSessionFactory().openSession()){
		  transaction = session.beginTransaction();
		  
		  session.update(user);
		  transaction.commit();
	  }catch(Exception e) {
		  if(transaction != null) {
			  transaction.rollback();
		  }
		  e.printStackTrace();
	  }
  }
  
  public List<UserRegistration> getAllUser(){
	  try(Session session = HibernateUtil.getSessionFactory().openSession()){
		  return session.createQuery("FROM UserRegistration where suspendedStatus = 0", UserRegistration.class).list();
	  }catch(Exception e) {
	   		e.printStackTrace();
	   		return null;
	   	}
  }
  
  public UserRegistration validateUser(String userName, String password) {
      Transaction transaction = null;
      UserRegistration user = null;

      try (Session session = HibernateUtil.getSessionFactory().openSession()) {
          transaction = session.beginTransaction();
          
          Query<UserRegistration> query = session.createQuery("FROM UserRegistration WHERE userName = :userName AND password = :password", UserRegistration.class);
          query.setParameter("userName", userName);
          query.setParameter("password", password);
          
          user = query.uniqueResult();
          
          transaction.commit();
      } catch (Exception e) {
          if (transaction != null) {
              transaction.rollback();
          }
          e.printStackTrace();
      }
      return user;
  }
  
  public UserRegistration findUserByEmail(String email) {
	    UserRegistration user = null;
	    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	        Query<UserRegistration> query = session.createQuery("FROM UserRegistration WHERE employeePersonalDetails.email = :email", UserRegistration.class);
	        query.setParameter("email", email);
	        user = query.uniqueResult();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return user;
	}
  
  public UserRegistration findUserByToken(String token) {
	  Transaction transaction = null;
	    UserRegistration user = null;
	    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	    	transaction = session.beginTransaction();
	    	
	    	Query<UserRegistration> query = session.createQuery("FROM UserRegistration WHERE resetToken = :token", UserRegistration.class);
	    	query.setParameter("token", token);
	    	
	    	user = query.uniqueResult();
	    	
	    	transaction.commit();
	    } catch (Exception e) {
	    	if (transaction != null) {
	    		transaction.rollback();
	    	}
	        e.printStackTrace();
	    }
	    return user;
	}


  
  
}

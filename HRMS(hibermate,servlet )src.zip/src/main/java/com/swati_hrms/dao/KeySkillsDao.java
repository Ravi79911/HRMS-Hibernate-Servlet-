package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;


import com.swati_hrms.model.KeySkills;
import com.swati_hrms.util.HibernateUtil;

public class KeySkillsDao {
	
	public void saveKeySkills(KeySkills keySkills) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.save(keySkills);
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public KeySkills getKeySkillsById(int id) {
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			return session.get(KeySkills.class, id);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void updateKeySkills(KeySkills keySkills) {
		Transaction transaction = null;
	       try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	           transaction = session.beginTransaction();
	           session.update(keySkills);
	           transaction.commit();
	       } catch (Exception e) {
	           if (transaction != null) {
	               transaction.rollback();
	           }
	           e.printStackTrace();
	       }
	}
	
	public List<KeySkills> getAllKeySkills(){
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
	   		return session.createQuery("FROM KeySkills where suspendedStatus = 0" , KeySkills.class).list();
	   	}catch(Exception e) {
	   		e.printStackTrace();
	   		return null;
	   	}
	   }
	}



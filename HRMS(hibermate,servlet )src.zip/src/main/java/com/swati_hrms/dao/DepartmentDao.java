package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.model.Department;
import com.swati_hrms.util.HibernateUtil;

public class DepartmentDao {
    
	public void saveDepartment(Department department) {
    	Transaction transaction = null;
    	try(Session session = HibernateUtil.getSessionFactory().openSession()){
    		transaction = session.beginTransaction();
    		
    		session.save(department);
    	}catch(Exception e) {
    		 if (transaction != null) {
                 transaction.rollback();
             }
    		 e.printStackTrace();
    	}
    }
    
 // Add other CRUD methods as needed (update, delete, getById, etc.)
    public Department getDepartmentById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Department.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public void updateDepartment(Department department) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(department);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    
    public List<Department> getAllDepartment(){
    	try(Session session = HibernateUtil.getSessionFactory().openSession()){
    		return session.createQuery("FROM Department where suspendedStatus = 0" , Department.class).list();
    	}catch(Exception e) {
    		e.printStackTrace();
    		return null;
    	}
    }
}

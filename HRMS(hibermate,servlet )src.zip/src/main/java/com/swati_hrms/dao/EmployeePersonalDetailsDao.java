package com.swati_hrms.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.swati_hrms.model.AddEmployeePayroll;
import com.swati_hrms.model.EmpJoiningDetails;
import com.swati_hrms.model.EmployeePersonalDetails;
import com.swati_hrms.util.HibernateUtil;

public class EmployeePersonalDetailsDao {

	public void saveEmployee(EmployeePersonalDetails employeePersonalDetails) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();

			session.save(employeePersonalDetails);
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	public EmployeePersonalDetails getEmployeeById(int id) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			return session.get(EmployeePersonalDetails.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void updateEmployee(EmployeePersonalDetails employeePersonalDetails) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();

			session.update(employeePersonalDetails);
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public boolean employeeExists(String employee_code) {
		
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        
        Query<EmployeePersonalDetails> query = session.createQuery("FROM EmployeePersonalDetails WHERE employee_code = :employee_code", EmployeePersonalDetails.class);
        query.setParameter("employee_code", employee_code);
        EmployeePersonalDetails employee = query.uniqueResult();
        
        session.getTransaction().commit();
        session.close();
        
        return employee != null;
    }
	

	public List<EmployeePersonalDetails> getAllEmployeeDetails() {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			List<EmployeePersonalDetails> employeeList = session.createQuery(
					"FROM EmployeePersonalDetails where suspendedStatus = 0", EmployeePersonalDetails.class).list();
			for (EmployeePersonalDetails empPersonalDetails : employeeList) {
				Hibernate.initialize(empPersonalDetails.getDependents());
				Hibernate.initialize(empPersonalDetails.getDocuments());
				Hibernate.initialize(empPersonalDetails.getEducationDetails());
				Hibernate.initialize(empPersonalDetails.getExperienceDetails());
				Hibernate.initialize(empPersonalDetails.getKeySkills());
				Hibernate.initialize(empPersonalDetails.getUserRegisteration());
				Hibernate.initialize(empPersonalDetails.getEmpJoiningDetails());
			}
			return employeeList;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public EmployeePersonalDetails getEmployeeWithDetails(int id) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			EmployeePersonalDetails empPersonalDetails = session.get(EmployeePersonalDetails.class, id);
			if (empPersonalDetails != null) {
				Hibernate.initialize(empPersonalDetails.getDependents());
				Hibernate.initialize(empPersonalDetails.getDocuments());
				Hibernate.initialize(empPersonalDetails.getEducationDetails());
				Hibernate.initialize(empPersonalDetails.getExperienceDetails());
				Hibernate.initialize(empPersonalDetails.getKeySkills());
				Hibernate.initialize(empPersonalDetails.getUserRegisteration());
				Hibernate.initialize(empPersonalDetails.getEmpJoiningDetails());
				Hibernate.initialize(empPersonalDetails.getEmployeePayroll());
				
				// Initialize many-to-one associations
	            for (AddEmployeePayroll payroll : empPersonalDetails.getEmployeePayroll()) {
	                Hibernate.initialize(payroll.getBasics());
	                Hibernate.initialize(payroll.getAllowances());
	                Hibernate.initialize(payroll.getDeductions());
	            }
			}
			return empPersonalDetails;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public EmployeePersonalDetails getEmployeeWithJoiningDetailsByCode(String employee_code) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Query<EmployeePersonalDetails> query = session.createQuery(
                    "FROM EmployeePersonalDetails WHERE employee_code = :employee_code", EmployeePersonalDetails.class);
            query.setParameter("employee_code", employee_code);
            EmployeePersonalDetails empPersonalDetails = query.uniqueResult();

            if (empPersonalDetails != null) {
                Hibernate.initialize(empPersonalDetails.getDependents());
                Hibernate.initialize(empPersonalDetails.getDocuments());
                Hibernate.initialize(empPersonalDetails.getEducationDetails());
                Hibernate.initialize(empPersonalDetails.getExperienceDetails());
                Hibernate.initialize(empPersonalDetails.getKeySkills());
                Hibernate.initialize(empPersonalDetails.getUserRegisteration());

                // Check if joining details exist
                EmpJoiningDetails joiningDetails = session.createQuery("FROM EmpJoiningDetails WHERE employeePersonalDetails.id = :id", EmpJoiningDetails.class)
                        .setParameter("id", empPersonalDetails.getId())
                        .uniqueResult();
                
                if (joiningDetails != null) {
                    Hibernate.initialize(empPersonalDetails.getEmpJoiningDetails());
                } else {
                    empPersonalDetails = null; // Set to null if no joining details are found
                }
            }
            transaction.commit();
            return empPersonalDetails;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
        return null;
    }
	
	 @SuppressWarnings({ "rawtypes", "unchecked" })
	public List<EmployeePersonalDetails> searchEmployees(String searchType, String searchValue) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction transaction = null;
	        List<EmployeePersonalDetails> employees = new ArrayList<>();

	        try {
	            transaction = session.beginTransaction();
	            String queryString = "from EmployeePersonalDetails where suspendedStatus = 0 and " + searchType + " = :searchValue";
	            Query query = session.createQuery(queryString);
	            query.setParameter("searchValue", searchValue);
	            employees = query.list();
	            transaction.commit();
	        } catch (HibernateException e) {
	            if (transaction != null) transaction.rollback();
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }

	        return employees;
	    }

}

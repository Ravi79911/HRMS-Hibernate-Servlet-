package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;


import com.swati_hrms.model.Designation;
import com.swati_hrms.util.HibernateUtil;

public class DesignationDao {

	public void saveDesignation(Designation designation) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			
			session.save(designation);
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	 // Add other CRUD methods as needed (update, delete, getById, etc.)
   public Designation getDesignationById(int id) {
	   try(Session session = HibernateUtil.getSessionFactory().openSession()){
		  return session.get(Designation.class, id);
	   }catch(Exception e) {
		   e.printStackTrace();
	   }
	   return null;
   }
   
   public void updateDesignation(Designation designation) {
       Transaction transaction = null;
       try (Session session = HibernateUtil.getSessionFactory().openSession()) {
           transaction = session.beginTransaction();
           session.update(designation);
           transaction.commit();
       } catch (Exception e) {
           if (transaction != null) {
               transaction.rollback();
           }
           e.printStackTrace();
       }
   }
   
   public List<Designation> getAllDesignation(){
   	try(Session session = HibernateUtil.getSessionFactory().openSession()){
   		return session.createQuery("FROM Designation where suspendedStatus = 0" , Designation.class).list();
   	}catch(Exception e) {
   		e.printStackTrace();
   		return null;
   	}
   }
}

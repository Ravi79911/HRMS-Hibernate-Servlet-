package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.model.AddEmployeePayroll;
import com.swati_hrms.model.EmployeeAllowance;
import com.swati_hrms.model.EmployeeBasic;
import com.swati_hrms.model.EmployeeDeduction;
import com.swati_hrms.util.HibernateUtil;

public class AddEmployeePayrollDao {
  
	public void saveEmployeePayroll(AddEmployeePayroll empPayroll) {
	    Transaction transaction = null;
	    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	        transaction = session.beginTransaction();
	        session.save(empPayroll);
	        transaction.commit();
	    } catch (Exception e) {
	        if (transaction != null) {
	            transaction.rollback();
	        }
	        e.printStackTrace();
	    }
	}

	
	public AddEmployeePayroll getEmpPayrollById(long id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            AddEmployeePayroll payroll = session.get(AddEmployeePayroll.class, id);
            if (payroll != null) {
                Hibernate.initialize(payroll.getBasics());
                Hibernate.initialize(payroll.getAllowances());
                Hibernate.initialize(payroll.getDeductions());
            }
            return payroll;
        }
    }
	
	
	public void updateEmployeePayroll(AddEmployeePayroll employeePayroll) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.update(employeePayroll);
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public List<AddEmployeePayroll> getAllPayroll(){
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			List<AddEmployeePayroll> payroll = session.createQuery("FROM AddEmployeePayroll WHERE suspendedStatus = 0", AddEmployeePayroll.class).list();
			
			session.close();
	        return payroll;
		}catch(Exception e) {
			 e.printStackTrace();
			 return null;
		 }
	}
	
	public void removeBasicFromPayroll(long payrollId, long basicId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            AddEmployeePayroll payroll = session.get(AddEmployeePayroll.class, payrollId);
            EmployeeBasic basic = session.get(EmployeeBasic.class, basicId);
            if (payroll != null && basic != null) {
                payroll.getBasics().remove(basic);
                session.update(payroll);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void removeAllowanceFromPayroll(long payrollId, long allowanceId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            AddEmployeePayroll payroll = session.get(AddEmployeePayroll.class, payrollId);
            EmployeeAllowance allowance = session.get(EmployeeAllowance.class, allowanceId);
            if (payroll != null && allowance != null) {
                payroll.getAllowances().remove(allowance);
                session.update(payroll);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }

    public void removeDeductionFromPayroll(long payrollId, long deductionId) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            AddEmployeePayroll payroll = session.get(AddEmployeePayroll.class, payrollId);
            EmployeeDeduction deduction = session.get(EmployeeDeduction.class, deductionId);
            if (payroll != null && deduction != null) {
                payroll.getDeductions().remove(deduction);
                session.update(payroll);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}

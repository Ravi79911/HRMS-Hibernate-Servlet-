package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.model.EmployeeExperienceDetails;
import com.swati_hrms.util.HibernateUtil;

public class EmpExperianceDao {

	public void saveEmpExperience(EmployeeExperienceDetails empExpDetails) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.save(empExpDetails);
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public EmployeeExperienceDetails getEmpExpById(int id) {
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			return session.get(EmployeeExperienceDetails.class, id);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void updateEmpExp(EmployeeExperienceDetails empExpDetails) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.update(empExpDetails);
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public List<EmployeeExperienceDetails> getAllEmpExpDetails(){
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			return session.createQuery("FROM EmployeeExperienceDetails where suspendedStatus = 0", EmployeeExperienceDetails.class).list();
		}catch (Exception e) {
            e.printStackTrace();
            return null;
	    }
	}
}



















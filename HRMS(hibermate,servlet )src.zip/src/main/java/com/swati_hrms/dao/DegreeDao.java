package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.model.Degree;
import com.swati_hrms.util.HibernateUtil;

public class DegreeDao {

    public void saveDegree(Degree degree) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();

            session.save(degree);

            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            // Replace with proper logging framework in a real application
            e.printStackTrace();
        }
    }

    // Add other CRUD methods as needed (update, delete, getById, etc.)
    public Degree getDegreeById(int id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Degree.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public void updateDegree(Degree degree) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.update(degree);
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
    
    public List<Degree> getAllDegrees() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Degree where suspendedStatus = 0", Degree.class).list();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    
}

package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.swati_hrms.model.EmpEducationDetails;
import com.swati_hrms.util.HibernateUtil;

public class EmployeeEducationDetailsDao {

	public void saveEducationDetails(EmpEducationDetails educationDetails) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();

			session.save(educationDetails);
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	public EmpEducationDetails getEmpEducationById(int id) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			return session.get(EmpEducationDetails.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void updateEmpEducationDetail(EmpEducationDetails educationDetails) {
		Transaction transaction = null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();

			session.update(educationDetails);
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}

	public List<EmpEducationDetails> getAllEmpEducationDetails(int empMasterId) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			Query<EmpEducationDetails> query = session.createQuery(
					"FROM EmpEducationDetails WHERE empMasterId = :empMasterId", EmpEducationDetails.class);
			query.setParameter("empMasterId", empMasterId);
			return query.list();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public List<EmpEducationDetails> getEmpEducationDetailsByEmpId() {
		try (Session session = HibernateUtil.getSessionFactory().openSession()) {
			return session.createQuery("FROM EmpEducationDetails where suspendedStatus = 0", EmpEducationDetails.class).list();
		}
	}
}

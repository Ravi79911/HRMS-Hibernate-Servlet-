package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.model.AddDocuments;
import com.swati_hrms.util.HibernateUtil;

public class AddDocumentsDao {
    
	public void saveDocument(AddDocuments addDocuments) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.save(addDocuments);
			transaction.commit();
			
			 System.out.println("Document saved successfully with ID: " + addDocuments.getId()); // Log success
		}catch(Exception e) {
//			if(transaction != null) {
//				transaction.rollback();
//			}
			e.printStackTrace();
		}
	}
	
	public AddDocuments getDocumentById(int id) {
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			return session.get(AddDocuments.class, id);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void updateDocument(AddDocuments addDocuments) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			transaction = session.beginTransaction();
			
			session.update(addDocuments);
			transaction.commit();
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	public List<AddDocuments> getAllDocuments(){
		try(Session session = HibernateUtil.getSessionFactory().openSession()){
			return session.createQuery("FROM AddDocuments where suspendedStatus = 0", AddDocuments.class).list();
		} catch (Exception e) {
            e.printStackTrace();
            return null;
	  }
	}
}

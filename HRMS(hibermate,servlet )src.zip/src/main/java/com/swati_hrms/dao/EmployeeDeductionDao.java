package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.swati_hrms.model.EmployeeDeduction;
import com.swati_hrms.util.HibernateUtil;

public class EmployeeDeductionDao {
	
	public void saveEmployeeDeduction(List<EmployeeDeduction> deduction) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            for (EmployeeDeduction deductions : deduction) {
                session.save(deductions);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
	
	 public EmployeeDeduction getDeductionById(Long id) {
	    	
	        try (Session session = HibernateUtil.getSessionFactory().openSession()){
	            return session.get(EmployeeDeduction.class, id);
	        
	        } catch (Exception e) {
	            e.printStackTrace();
	        } 
	        return null;
	    }
	 
	 public EmployeeDeduction getBasicByDeductionNameAndValue(String deductionName, Double deductionValue) {
		    EmployeeDeduction employeeDeduction = null;
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            // Create a query to search by scaleName and scaleValue
	            String hql = "FROM EmployeeDeduction WHERE deductionName = :deductionName AND deductionValue = :deductionValue";
	            Query<EmployeeDeduction> query = session.createQuery(hql, EmployeeDeduction.class);
	            query.setParameter("deductionName", deductionName);
	            query.setParameter("deductionValue", deductionValue);
	            
	            List<EmployeeDeduction> results = query.list();
	            if (!results.isEmpty()) {
	            	employeeDeduction = results.get(0); // Assuming you expect only one result
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return employeeDeduction;
	    }
	 
	 public EmployeeDeduction updateDeduction(EmployeeDeduction employeeDeduction) {
		  Transaction transaction = null;
		  
		  try (Session session=HibernateUtil.getSessionFactory().openSession()){ 
			  transaction = session.beginTransaction(); 
		  		session.update(employeeDeduction);
		  		transaction.commit();
		  		} catch (Exception e) { 
		  			if (transaction != null) transaction.rollback();
		  			e.printStackTrace();
		  			} 
		  return employeeDeduction;
		}
	 
	 public List<EmployeeDeduction> getAllDeduction() {
		 try(Session session = HibernateUtil.getSessionFactory().openSession()){
			 List<EmployeeDeduction> basics = session.createQuery("FROM EmployeeDeduction WHERE suspendedStatus = 0", EmployeeDeduction.class).list();
		        session.close();
		        return basics;
		 }catch(Exception e) {
			 e.printStackTrace();
			 return null;
		 }
	   
	  }
	 
	 public EmployeeDeduction getDeductionByName(String deductionName) {
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            // Assuming scaleName is unique or you only want the first match
	            return session.createQuery("FROM EmployeeDeduction WHERE deductionName = :deductionName AND suspendedStatus = 0", EmployeeDeduction.class)
	                          .setParameter("deductionName", deductionName)
	                          .setMaxResults(1) // Ensure only one result is returned
	                          .uniqueResult();
	        } catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
	    }

}

package com.swati_hrms.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;


import com.swati_hrms.model.Streams;
import com.swati_hrms.util.HibernateUtil;

public class StreamsDao {
	public void saveStreams(Streams streams) {
		Transaction transaction = null;
		try(Session session = HibernateUtil.getSessionFactory().openSession()) {
			transaction = session.beginTransaction();
			
			session.save(streams);
		}catch(Exception e) {
			if(transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}
	
	 // Add other CRUD methods as needed (update, delete, getById, etc.)
   public Streams getStreamsById(int id) {
	   try(Session session = HibernateUtil.getSessionFactory().openSession()){
		  return session.get(Streams.class, id);
	   }catch(Exception e) {
		   e.printStackTrace();
	   }
	   return null;
   }
   
   public void updateStreams(Streams streams) {
       Transaction transaction = null;
       try (Session session = HibernateUtil.getSessionFactory().openSession()) {
           transaction = session.beginTransaction();
           session.update(streams);
           transaction.commit();
       } catch (Exception e) {
           if (transaction != null) {
               transaction.rollback();
           }
           e.printStackTrace();
       }
   }
   
   public List<Streams> getAllStreams(){
   	try(Session session = HibernateUtil.getSessionFactory().openSession()){
   		return session.createQuery("FROM Streams where suspendedStatus = 0" , Streams.class).list();
   	}catch(Exception e) {
   		e.printStackTrace();
   		return null;
   	}
   }
}

package com.swati_hrms.web;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DepartmentDao;
import com.swati_hrms.dao.DesignationDao;
import com.swati_hrms.dao.EmpJoiningDao;
import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.Department;
import com.swati_hrms.model.Designation;
import com.swati_hrms.model.EmpJoiningDetails;
import com.swati_hrms.model.EmployeePersonalDetails;

@WebServlet("/employeeJoiningDetails")
public class EmployeeJoiningDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EmployeeJoiningDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");

		if (idStr != null && !idStr.isEmpty()) {
			try {
				int id = Integer.parseInt(idStr);
				EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);

				if (employeeDetails != null) {
					request.setAttribute("employeeDetails", employeeDetails);

					DesignationDao designationDao = new DesignationDao();
					List<Designation> designation = designationDao.getAllDesignation();

					if (designation != null) {
						request.setAttribute("designation", designation);
					}

					DepartmentDao departmentDao = new DepartmentDao();
					List<Department> department = departmentDao.getAllDepartment();

					if (department != null) {
						request.setAttribute("department", department);
					}
					request.getRequestDispatcher("Admin/empJoiningDetails.jsp").forward(request, response);
				} else {
					request.setAttribute("errorMessage", "Employee not found with ID: " + id);
					response.sendRedirect("listRegisterMaster");
				}
			} catch (Exception e) {
				e.printStackTrace();
				response.sendRedirect("listRegisterMaster");
			}
		} else {
			response.sendRedirect("listRegisterMaster");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");

		if (idStr != null && !idStr.isEmpty()) {
			try {
				int id = Integer.parseInt(idStr);
				EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);

				if (employeeDetails != null) {
					String designationStr = request.getParameter("designation");
					int designationId = Integer.parseInt(designationStr);

					String departmentStr = request.getParameter("department");
					int departmentId = Integer.parseInt(departmentStr);

					String JoinDateStr = request.getParameter("joinDate");
					LocalDate joinDate = LocalDate.parse(JoinDateStr);

					String location = request.getParameter("location");

					// fetch designation and department object from dao class
					DesignationDao designationDao = new DesignationDao();
					Designation designation = designationDao.getDesignationById(designationId);

					DepartmentDao departmentDao = new DepartmentDao();
					Department department = departmentDao.getDepartmentById(departmentId);

					// Create Employee Joining Details
					EmpJoiningDetails empJoiningDetails = new EmpJoiningDetails();
					empJoiningDetails.setEmployeePersonalDetails(employeeDetails);
					empJoiningDetails.setDepartment(department); // set department object
					empJoiningDetails.setDepartmentName(empJoiningDetails.getDepartment().getDepartment());
					empJoiningDetails.setDesignation(designation);
					empJoiningDetails.setDesignationName(empJoiningDetails.getDesignation().getDesignation());
					empJoiningDetails.setJoiningDate(joinDate);
					empJoiningDetails.setLocation(location);
					empJoiningDetails.setCreatedBy("Admin");

					// Save Employee Joining Details
					EmpJoiningDao empJoiningDao = new EmpJoiningDao();
					empJoiningDao.saveEmpJoining(empJoiningDetails);

					// Redirect to Employee Register list page
					response.sendRedirect("listRegisterMaster");

				} else {
					request.setAttribute("errorMessage", "Employee not found with ID: " + id);
					response.sendRedirect("listRegisterMaster");
				}
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
				response.sendRedirect("listRegisterMaster");
			}

		}

	}

}

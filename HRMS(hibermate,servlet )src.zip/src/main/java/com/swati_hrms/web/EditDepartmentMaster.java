package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DepartmentDao;
import com.swati_hrms.model.Department;

@WebServlet("/editDepartmentMaster")
public class EditDepartmentMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EditDepartmentMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				DepartmentDao departmentDao = new DepartmentDao();
				Department department = departmentDao.getDepartmentById(id);

				if (department != null) {
					request.setAttribute("department", department);
					request.getRequestDispatcher("Admin/editDepartmentMaster.jsp").forward(request, response);

				} else {
					request.setAttribute("errorMessage", "Department not found with ID: " + id);
					response.sendRedirect("listDepartmentMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid department ID format");
				response.sendRedirect("listDepartmentMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error fetching department: " + e.getMessage());
				response.sendRedirect("listDepartmentMaster");
			}

		} else {
			request.setAttribute("errorMessage", "Department ID parameter is missing");
			response.sendRedirect("listDepartmentMaster");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		String deptName = request.getParameter("department");
		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				DepartmentDao departmentDao = new DepartmentDao();
				Department department = departmentDao.getDepartmentById(id);

				if (department != null) {
					department.setDepartment(deptName);
					departmentDao.updateDepartment(department);

					// redirect to department list page
					response.sendRedirect("listDepartmentMaster");
				} else {
					request.setAttribute("errorMessage", "Department not found with ID: " + id);
					response.sendRedirect("listDepartmentMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid department ID format");
				response.sendRedirect("listDepartmentMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error fetching department: " + e.getMessage());
				response.sendRedirect("listDepartmentMaster");
			}

		} else {
			request.setAttribute("errorMessage", "Department ID parameter is missing");
			response.sendRedirect("listDepartmentMaster");
		}
	}

}

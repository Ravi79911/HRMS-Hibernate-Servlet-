package com.swati_hrms.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.EmployeePersonalDetails;



/**
 * Servlet implementation class SearchEmployeeServlet
 */
@WebServlet("/searchEmployeePayroll")
public class SearchEmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	private EmployeePersonalDetailsDao employeeDAO = new EmployeePersonalDetailsDao();
    public SearchEmployeeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  String searchType = request.getParameter("searchType");
		    String searchValue = request.getParameter("searchValue");
            
		    EmployeePersonalDetailsDao employeeDAO = new EmployeePersonalDetailsDao();
		    List<EmployeePersonalDetails> employees = employeeDAO.searchEmployees(searchType, searchValue);

		   if(employees !=null) {
		    request.setAttribute("employeeDetails", employees);

		    request.getRequestDispatcher("Admin/searchEmployeePayroll.jsp").forward(request, response);
		   }else {
			   request.setAttribute("errorMessage", "Employee not found or joining details not available for : " + searchValue );
			   request.getRequestDispatcher("Admin/searchEmployeePayroll.jsp").forward(request, response);
		   }
		}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

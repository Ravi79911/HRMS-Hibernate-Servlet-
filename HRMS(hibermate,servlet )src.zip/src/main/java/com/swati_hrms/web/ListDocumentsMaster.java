package com.swati_hrms.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DocumentsDao;
import com.swati_hrms.model.Documents;


@WebServlet("/listDocumentsMaster")
public class ListDocumentsMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ListDocumentsMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			DocumentsDao documentDao = new DocumentsDao();
			List<Documents> documents = documentDao.getAllDocuments();
			
			request.setAttribute("documents", documents);
			
			request.getRequestDispatcher("Admin/listDocumentsMaster.jsp").forward(request, response);
		}catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error fetching documents: " + e.getMessage());
        }
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

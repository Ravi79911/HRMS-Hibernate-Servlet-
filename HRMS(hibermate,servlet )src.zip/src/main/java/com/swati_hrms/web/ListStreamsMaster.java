package com.swati_hrms.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DesignationDao;
import com.swati_hrms.dao.StreamsDao;
import com.swati_hrms.model.Designation;
import com.swati_hrms.model.Streams;


@WebServlet("/listStreamsMaster")
public class ListStreamsMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ListStreamsMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			StreamsDao streamsDao = new StreamsDao();
			List<Streams> streams = streamsDao.getAllStreams();
			request.setAttribute("streams", streams);
			
			request.getRequestDispatcher("Admin/listStreamsMaster.jsp").forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
			response.getWriter().println("Error fetching streams: " + e.getMessage());
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

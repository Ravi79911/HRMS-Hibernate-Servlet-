package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.KeySkillsDao;
import com.swati_hrms.dao.StreamsDao;
import com.swati_hrms.model.KeySkills;
import com.swati_hrms.model.Streams;


@WebServlet("/editStreamsMaster")
public class EditStreamsMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public EditStreamsMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				StreamsDao streamsDao = new StreamsDao();
				Streams streams = streamsDao.getStreamsById(id);

				if (streams != null) {
					request.setAttribute("streams", streams);
					request.getRequestDispatcher("Admin/editStreamsMaster.jsp").forward(request, response);
				} else {
					request.setAttribute("errorMessage", "Stream not found with ID: " + id);
					response.sendRedirect("listStreamsMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid stream ID format");
				response.sendRedirect("listStreamsMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error fetching stream: " + e.getMessage());
				response.sendRedirect("listStreamsMaster");
			}
		} else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "Stream ID parameter is missing");
			response.sendRedirect("listStreamsMaster");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		String streamName = request.getParameter("stream");
		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				StreamsDao streamsDao = new StreamsDao();
				Streams streams = streamsDao.getStreamsById(id);

				if (streams != null) {
					streams.setStream(streamName);
					
					streamsDao.updateStreams(streams);
					response.sendRedirect("listStreamsMaster");
				} else {
					request.setAttribute("errorMessage", "Stream not found with ID: " + id);
					response.sendRedirect("listStreamsMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid stream ID format");
				response.sendRedirect("listStreamsMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error fetching stream: " + e.getMessage());
				response.sendRedirect("listStreamsMaster");
			}
		} else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "stream ID parameter is missing");
			response.sendRedirect("listStreamsMaster");
		}
	}

}

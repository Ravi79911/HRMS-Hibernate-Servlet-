package com.swati_hrms.web;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.swati_hrms.dao.AddDocumentsDao;
import com.swati_hrms.dao.DocumentsDao;
import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.AddDocuments;
import com.swati_hrms.model.Documents;
import com.swati_hrms.model.EmployeePersonalDetails;

@WebServlet("/addDocs")
@MultipartConfig
public class AddDocs extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final long MAX_FILE_SIZE = 307200; // 300KB

    public AddDocs() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");
        if (idStr != null && !idStr.isEmpty()) {
            try {
                int id = Integer.parseInt(idStr);
                EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
                EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);

                if (employeeDetails != null) {
                    request.setAttribute("employeeDetails", employeeDetails);
                    
                    DocumentsDao docsDao = new DocumentsDao();
                    List<Documents> documents = docsDao.getAllDocuments();
                    if(documents != null) {
                    	request.setAttribute("document", documents);
                     request.getRequestDispatcher("Admin/addDocuments.jsp").forward(request, response);
                    }
                   
                } else {
                    request.setAttribute("errorMessage", "Employee not found with ID: " + id);
                    response.sendRedirect("listRegisterMaster");
                }
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("listRegisterMaster");
            }
        } else {
            response.sendRedirect("listRegisterMaster");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");
        if (idStr != null && !idStr.isEmpty()) {
            try {
                int id = Integer.parseInt(idStr);
                EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
                EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);

                if (employeeDetails != null) {
                    String docIdStr = request.getParameter("docs");
                    int docId = Integer.parseInt(docIdStr);
                    
                   // fetch document from the dao class
                    DocumentsDao documentDao = new DocumentsDao();
                    Documents documents = documentDao.getDocumentById(docId);
                    
                    Part filePart = request.getPart("uploadDoc");
                    String fileName = filePart.getSubmittedFileName();
                    
                    if (filePart != null && filePart.getSize() <= MAX_FILE_SIZE) {
                        ServletContext context = getServletContext();
                        String uploadPath = context.getRealPath("/uploads");
                        System.out.println(uploadPath); //print path to console

                        // Ensure the upload directory exists
                        File uploadDir = new File(uploadPath);
                        if (!uploadDir.exists()) {
                            uploadDir.mkdirs();
                        }

                        // Save the file to the specified directory
                        String filePath = uploadPath + File.separator + fileName;
                        filePart.write(filePath);

                        // Create Employee Documents object 
                        AddDocuments addDocs = new AddDocuments();
                        addDocs.setEmployeePersonalDetails(employeeDetails);
                        addDocs.setDocuments(documents); //save the document object
                        addDocs.setDocName(addDocs.getDocuments().getDocName());
                        addDocs.setFileName(fileName);  // Save file name in the database
                        addDocs.setCreatedBy("Admin");

                        // Save to database using DAO
                        AddDocumentsDao addDocumentsDao = new AddDocumentsDao();
                        addDocumentsDao.saveDocument(addDocs);
                        response.sendRedirect(request.getContextPath() + "/listRegisterMaster?success=true");
                        System.out.println("Document added: " + addDocs);
                    } else {
                        request.setAttribute("errorMessage", "File size exceeds limit (300KB) or no file uploaded.");
                        request.getRequestDispatcher("Admin/addDocuments.jsp").forward(request, response);
                    }
                } else {
                    response.sendRedirect("listRegisterMaster");
                }
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("listRegisterMaster");
            }
        } else {
            response.sendRedirect("listRegisterMaster");
        }
    }
}

package com.swati_hrms.web;

import java.io.IOException;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.AddEmployeePayrollDao;
import com.swati_hrms.dao.EmployeeAllowanceDao;
import com.swati_hrms.dao.EmployeeBasicDao;
import com.swati_hrms.dao.EmployeeDeductionDao;
import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.AddEmployeePayroll;
import com.swati_hrms.model.EmployeeAllowance;
import com.swati_hrms.model.EmployeeBasic;
import com.swati_hrms.model.EmployeeDeduction;
import com.swati_hrms.model.EmployeePersonalDetails;

/**
 * Servlet implementation class EmployeeDetails
 */
@WebServlet("/viewEmployeeByIdDetail")
public class AllDetailsByIdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AllDetailsByIdServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		String scaleName = request.getParameter("scaleName");
		String allowanceName = request.getParameter("allowanceName");
	    if (idStr != null) {
	         int id = Integer.parseInt(idStr);

	        EmployeePersonalDetailsDao employeeMasterDAO = new EmployeePersonalDetailsDao();
	        EmployeePersonalDetails employee = employeeMasterDAO.getEmployeeWithDetails(id);
	        System.out.println(employee);
	        request.setAttribute("employee", employee);
	        
	        
	        
	        EmployeeBasicDao basicDao = new EmployeeBasicDao();
	        List<EmployeeBasic> basics = basicDao.getAllBasics();
	         if(basics != null) {
	        	 request.setAttribute("basics", basics);
	         }
	         
	         EmployeeDeductionDao deductionDao = new EmployeeDeductionDao();
	         List<EmployeeDeduction> deduction = deductionDao.getAllDeduction();
	         if(deduction != null) {
	        	 request.setAttribute("deduction", deduction);
	         }
	         
	         EmployeeAllowanceDao allowanceDao = new EmployeeAllowanceDao();
	         List<EmployeeAllowance> allowances = allowanceDao.getAllAllowance();
	         if(allowances != null) {
	        	 request.setAttribute("allowances", allowances);
	         }
	         // Fetch the specific EmployeeBasic by scaleName
             if (scaleName != null && !scaleName.isEmpty()) {
                 EmployeeBasic scale = basicDao.getScaleByName(scaleName);
                 request.setAttribute("scale", scale);
             }
             
             if(allowanceName != null && !allowanceName.isEmpty()) {
            	 EmployeeAllowance allowance = allowanceDao.getAllowanceByName(allowanceName);
            	 request.setAttribute("allowance", allowance);
             }
	         
	         
	        request.getRequestDispatcher("Admin/addPayRoll.jsp").forward(request, response);
	    } else {
	        response.sendRedirect("listRegisterMaster");
	    }}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
	        // Retrieve employee ID
	        String idStr = request.getParameter("id");
	        if (idStr == null || idStr.isEmpty()) {
	            response.sendRedirect("listRegisterMaster?error=InvalidEmployeeId");
	            return;
	        }

	        int employeeId;
	        try {
	            employeeId = Integer.parseInt(idStr);
	        } catch (NumberFormatException e) {
	            response.sendRedirect("listRegisterMaster?error=InvalidEmployeeId");
	            return;
	        }

	        // Retrieve employee details
	        EmployeePersonalDetailsDao employeeDao = new EmployeePersonalDetailsDao();
	        EmployeePersonalDetails employee = employeeDao.getEmployeeWithDetails(employeeId);
	        if (employee == null) {
	            response.sendRedirect("listRegisterMaster?error=EmployeeNotFound");
	            return;
	        }

	        // Retrieve form data
	        String[] scaleNames = request.getParameterValues("scaleName[]");
	        String[] scaleValues = request.getParameterValues("scaleValue[]");
	        String[] allowanceNames = request.getParameterValues("allowanceName[]");
	        String[] allowanceValues = request.getParameterValues("allowanceValue[]");
	        String[] deductionNames = request.getParameterValues("deductionName[]");
	        String[] deductionValues = request.getParameterValues("deductionValue[]");

	        if (scaleNames == null || scaleValues == null || allowanceNames == null || allowanceValues == null || deductionNames == null || deductionValues == null) {
	            response.sendRedirect("listRegisterMaster?error=InvalidFormData");
	            return;
	        }

	        EmployeeBasicDao basicDao = new EmployeeBasicDao();
	        EmployeeAllowanceDao allowanceDao = new EmployeeAllowanceDao();
	        EmployeeDeductionDao deductionDao = new EmployeeDeductionDao();
	        AddEmployeePayrollDao payrollDao = new AddEmployeePayrollDao();

	        // Create a payroll entry object
	        AddEmployeePayroll payroll = new AddEmployeePayroll();
	        payroll.setEmployeePersonalDetails(employee);
	        payroll.setCreatedBy("admin");

	        // Process scales
	        Set<EmployeeBasic> basics = new HashSet<>();
	        for (int i = 0; i < scaleNames.length; i++) {
	            try {
	                String scaleName = scaleNames[i];
	                Double scaleValue = Double.parseDouble(scaleValues[i]);
	                EmployeeBasic basic = basicDao.getBasicByScaleNameAndValue(scaleName, scaleValue);
	                if (basic != null) {
	                    basics.add(basic);
	                }
	            } catch (NumberFormatException e) {
	                e.printStackTrace();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	        payroll.setBasics(basics);

	        // Process allowances
	        Set<EmployeeAllowance> allowances = new HashSet<>();
	        for (int i = 0; i < allowanceNames.length; i++) {
	            try {
	                String allowanceName = allowanceNames[i];
	                Double allowanceValue = Double.parseDouble(allowanceValues[i]);
	                EmployeeAllowance allowance = allowanceDao.getBasicByAllowanceNameAndValue(allowanceName, allowanceValue);
	                if (allowance != null) {
	                    allowances.add(allowance);
	                }
	            } catch (NumberFormatException e) {
	                e.printStackTrace();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	        payroll.setAllowances(allowances);

	        // Process deductions
	        Set<EmployeeDeduction> deductions = new HashSet<>();
	        for (int i = 0; i < deductionNames.length; i++) {
	            try {
	                String deductionName = deductionNames[i];
	                Double deductionValue = Double.parseDouble(deductionValues[i]);
	                EmployeeDeduction deduction = deductionDao.getBasicByDeductionNameAndValue(deductionName, deductionValue);
	                if (deduction != null) {
	                    deductions.add(deduction);
	                }
	            } catch (NumberFormatException e) {
	                e.printStackTrace();
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	        payroll.setDeductions(deductions);

	        // Save payroll
	        payrollDao.saveEmployeePayroll(payroll);

	        response.sendRedirect("listRegisterMaster?success=DataSaved");
	    } catch (Exception e) {
	        e.printStackTrace(); // Consider using a logging framework
	        response.sendRedirect("listRegisterMaster?error=InternalServerError");
	    }
	}


}

package com.swati_hrms.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DegreeDao;
import com.swati_hrms.model.Degree;

/**
 * Servlet implementation class ListDegreeMaster
 */
@WebServlet("/listDegreeMaster")
public class ListDegreeMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListDegreeMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			DegreeDao degreeDao = new DegreeDao();
			List<Degree> degrees = degreeDao.getAllDegrees();
			
			request.setAttribute("degrees", degrees);
			
			request.getRequestDispatcher("Admin/listDegreeMaster.jsp").forward(request, response);
		}catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error fetching degrees: " + e.getMessage());
        }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.swati_hrms.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.EmployeePersonalDetails;


@WebServlet("/createLogin")
public class CreateLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public CreateLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
		List<EmployeePersonalDetails> empAllDetails = employeeDetailsDao.getAllEmployeeDetails();
		try {
			if(empAllDetails != null) {
				request.setAttribute("empAllDetails", empAllDetails);
				
				request.getRequestDispatcher("Admin/createLogin.jsp").forward(request, response);
			}else {
				request.setAttribute("errorMessage", "Employee not found");
				response.sendRedirect("employeeLogin");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
			response.sendRedirect("employeeLogin");
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

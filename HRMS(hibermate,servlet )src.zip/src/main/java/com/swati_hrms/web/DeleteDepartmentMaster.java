package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DepartmentDao;
import com.swati_hrms.model.Department;


@WebServlet("/deleteDepartmentMaster")
public class DeleteDepartmentMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DeleteDepartmentMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		
		if(idStr != null && !idStr.isEmpty()) {
			try {
				int id = Integer.parseInt(idStr);
				
				DepartmentDao departmentDao = new DepartmentDao();
				Department department = departmentDao.getDepartmentById(id);
				
				if(department != null) {
					// Mark the department as suspended (inactive)
					department.setSuspendedStatus(1);
					
					// Update the department in the database
					departmentDao.updateDepartment(department);
					
					response.sendRedirect(request.getContextPath() + "/listDepartmentMaster");
				}else {
					response.getWriter().println("Department with ID " + id + " not found");
				}
				
			}catch(Exception e) {
				 response.getWriter().println("Error deleting degree: " + e.getMessage());
			}
		}else {
			 response.getWriter().println("Department ID parameter is missing or empty");
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

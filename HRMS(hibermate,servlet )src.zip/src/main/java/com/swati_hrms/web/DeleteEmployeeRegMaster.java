package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.EmployeePersonalDetails;


@WebServlet("/deleteEmployeeRegMaster")
public class DeleteEmployeeRegMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteEmployeeRegMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		
		if(idStr != null) {
			try {
				int id = Integer.parseInt(idStr);
				
				EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employee = employeeDetailsDao.getEmployeeById(id);
				
				if(employee != null) {
					// Mark the designation as suspended (inactive)
					employee.setSuspendedStatus(1);
					
					// Update the designation in the database
					employeeDetailsDao.updateEmployee(employee);
					
					response.sendRedirect(request.getContextPath() + "/listRegisterMaster");
				}else {
					response.getWriter().println("Employee with ID " + id + " not found");
				}
			}catch(Exception e) {
				e.printStackTrace();
				response.getWriter().println("Error deleting employee: " + e.getMessage());
			}
			
		}else {
			response.getWriter().println("Employee ID parameter is missing or empty");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

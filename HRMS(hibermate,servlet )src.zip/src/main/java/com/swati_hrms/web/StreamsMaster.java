package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DegreeDao;
import com.swati_hrms.dao.StreamsDao;
import com.swati_hrms.model.Degree;
import com.swati_hrms.model.Streams;


@WebServlet("/streamsMaster")
public class StreamsMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public StreamsMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String streamName = request.getParameter("stream"); 

        if (streamName != null && !streamName.isEmpty()) {
            try {
                Streams streams = new Streams();
                streams.setStream(streamName);
                streams.setCreatedBy("Admin"); // Example Name as admin(change when set the user)
                

                StreamsDao streamsDao = new StreamsDao();
                streamsDao.saveStreams(streams);

                response.sendRedirect(request.getContextPath() + "/listStreamsMaster");
                return; // Stop further execution
            } catch (Exception e) {
                response.getWriter().println("Error saving stream: " + e.getMessage());
            }
        } else {
            response.getWriter().println("Stream name parameter is missing or empty");
        }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

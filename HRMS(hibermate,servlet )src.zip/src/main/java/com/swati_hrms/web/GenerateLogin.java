package com.swati_hrms.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.dao.RolesDao;
import com.swati_hrms.dao.UserRegistrationDao;
import com.swati_hrms.model.EmployeePersonalDetails;
import com.swati_hrms.model.Roles;
import com.swati_hrms.model.UserRegistration;

/**
 * Servlet implementation class GenerateLogin
 */
@WebServlet("/generateLogin")
public class GenerateLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public GenerateLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");

		if(idStr != null && !idStr.isEmpty()) {
			try {
				int id = Integer.parseInt(idStr);
				EmployeePersonalDetailsDao empPersonalDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employeeDetails = empPersonalDetailsDao.getEmployeeWithDetails(id);
				
				if(employeeDetails != null) {
					request.setAttribute("employeeDetails", employeeDetails);
					
					RolesDao rolesDao = new RolesDao();
		            List<Roles> roles = rolesDao.getAllRoles();
		            if (roles != null) {
		                request.setAttribute("roles", roles);
		            }
				
				request.getRequestDispatcher("Admin/empGenerateLogin.jsp").forward(request, response);
				}else {
					request.setAttribute("errorMessage", "Employee not found with ID: " + id);
					response.sendRedirect("employeeLogin");
				}
			}catch(Exception e) {
				request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
				response.sendRedirect("employeeLogin");
			}
			
		}else {
			request.setAttribute("errorMessage", "Employee ID parameter is missing");
			response.sendRedirect("employeeLogin");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		
		if(idStr != null && !idStr.isEmpty()) {
			try {
				int id = Integer.parseInt(idStr);
				EmployeePersonalDetailsDao empPersonalDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employeeDetails = empPersonalDetailsDao.getEmployeeWithDetails(id);
				
				if(employeeDetails != null) {
					String username = request.getParameter("username");
					String password = "Ranchi@2024";
					String roleStr = request.getParameter("roles");
					int roleId = Integer.parseInt(roleStr);
					
					RolesDao rolesDao = new RolesDao();
					Roles roles = rolesDao.getRoleById(roleId);
					
					UserRegistration user = new UserRegistration();
					user.setEmployeePersonalDetails(employeeDetails);
					user.setCreatedBy("Admin"); //to be update with user login
					user.setUpdatedBy("Admin"); //to be update with user login
					user.setUserName(username);
					user.setPassword(password); //save default password
					user.setLastPassword(user.getPassword());
					user.setRole(roles); //save the roles object
					user.setRoleName(user.getRole().getRoleName());
					
					UserRegistrationDao userRegDao = new UserRegistrationDao();
					userRegDao.saveUser(user);
					
					response.sendRedirect(request.getContextPath() + "/employeeLogin");
				}else {
					 request.setAttribute("errorMessage", "Employee not found with ID: " + id);
					response.sendRedirect("employeeLogin");
				}
					
			}catch(Exception e) {
				request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
				response.sendRedirect("employeeLogin");
		   }
		}else {
			request.setAttribute("errorMessage", "Employee ID parameter is missing");
			response.sendRedirect("employeeLogin");
		}
		
	}

}

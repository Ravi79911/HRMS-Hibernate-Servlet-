package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.KeySkillsDao;
import com.swati_hrms.model.KeySkills;


@WebServlet("/keySkillsMaster")
public class KeySkillsMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public KeySkillsMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String skillName = request.getParameter("skill");
		
		if(skillName != null && !skillName.isEmpty()) {
			try {
				KeySkills keySkills = new KeySkills();
				keySkills.setSkillName(skillName);
				keySkills.setCreatedBy("Admin");
				
				KeySkillsDao keySkillsDao = new KeySkillsDao();
				keySkillsDao.saveKeySkills(keySkills);
				
				response.sendRedirect(request.getContextPath() + "/listKeySkillsMaster");
			}catch(Exception e) {
				response.getWriter().println("Error saving keySkills: " + e.getMessage());
			}
		}else {
			response.getWriter().println("Skill name parameter is missing or empty");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

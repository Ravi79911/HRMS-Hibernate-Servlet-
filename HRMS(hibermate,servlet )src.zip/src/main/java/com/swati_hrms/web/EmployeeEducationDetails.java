package com.swati_hrms.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.swati_hrms.dao.DegreeDao;
import com.swati_hrms.dao.EmployeeEducationDetailsDao;
import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.dao.StreamsDao;
import com.swati_hrms.model.EmployeePersonalDetails;
import com.swati_hrms.model.Streams;
import com.swati_hrms.model.Degree;
import com.swati_hrms.model.EmpEducationDetails;

/**
 * Servlet implementation class EmployeeEducationDetails
 */
@WebServlet("/employeeEducationDetails")
public class EmployeeEducationDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeEducationDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idParam = request.getParameter("id");
		
		if(idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);
				
				if(employeeDetails != null) {
					request.setAttribute("employeeDetails", employeeDetails);
				
					//Create Degree Dao object to store value of degree
					DegreeDao degreeDao = new DegreeDao();
					List<Degree> degree = degreeDao.getAllDegrees();
					if(degree != null) {
					System.out.println("Number of key skills fetched: " + degree.size());
					request.setAttribute("degree", degree);
					
					StreamsDao streamsDao = new StreamsDao();
					List<Streams> streams = streamsDao.getAllStreams();
					if(streams != null) {
						System.out.println("Number of streams fetched: " + streams.size());
						request.setAttribute("streams", streams);
						
						//Dispatch to the educationDetails.jsp Page
						request.getRequestDispatcher("Admin/educationDetails.jsp").forward(request, response);
					}
					
					}
					
				}else {
					request.setAttribute("errorMessage", "Employee not found with ID: " + id);
					response.sendRedirect("listRegisterMaster");
				}
			}catch(Exception e) {
				request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
				response.sendRedirect("listRegisterMaster");
			}
			
		}else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "Employee ID parameter is missing");
			response.sendRedirect("listRegisterMaster");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String idParam = request.getParameter("id");
	    if(idParam != null && !idParam.isEmpty()) {
	        try {
	            int id = Integer.parseInt(idParam);
	            EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
	            EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);

	            if(employeeDetails != null) {
	                // Fetch degree and course details from request parameters
	                String degreeIdStr = request.getParameter("degree");
	                int degreeId = Integer.parseInt(degreeIdStr);
	                
	                String universityName = request.getParameter("university");
	                
	                String courseIdStr = request.getParameter("courseStreams");
	                int courseId = Integer.parseInt(courseIdStr);
	                
	                String passingYear = request.getParameter("passingYear");
	                String cgpaPercentage = request.getParameter("cgpaPercentage");

	                // Fetch degree and course objects from DAO classes
	                DegreeDao degreeDao = new DegreeDao();
	                Degree degree = degreeDao.getDegreeById(degreeId);
	                
	                StreamsDao streamsDao = new StreamsDao();
	                Streams streams = streamsDao.getStreamsById(courseId);

	                // Create EmpEducationDetails object and set values
	                EmpEducationDetails empEduDetails = new EmpEducationDetails();
	                empEduDetails.setEmployeePersonalDetails(employeeDetails);
	                empEduDetails.setDegree(degree); // Set degree object
	                empEduDetails.setDegreeName(empEduDetails.getDegree().getDegree());
	                empEduDetails.setUniversityBoard(universityName);
	                empEduDetails.setStreamCourse(streams); // Set streams object
	                empEduDetails.setStreamCourseName(empEduDetails.getStreamCourse().getStream());
	                empEduDetails.setPassingYear(passingYear);
	                empEduDetails.setCgpaPercentage(cgpaPercentage);
	                empEduDetails.setCreatedBy("Admin");
                    
	                // Save EmpEducationDetails using DAO
	                EmployeeEducationDetailsDao empEducationDao = new EmployeeEducationDetailsDao();
	                empEducationDao.saveEducationDetails(empEduDetails);
	                

	                // Redirect to Employee Register list page
	                response.sendRedirect("listRegisterMaster");
	            } else {
	                request.setAttribute("errorMessage", "Employee not found with ID: " + id);
	                response.sendRedirect("listRegisterMaster");
	            }
	        } catch(Exception e) {
	            request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
	            response.sendRedirect("listRegisterMaster");
	        }
	    }
	}



}

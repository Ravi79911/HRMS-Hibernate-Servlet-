package com.swati_hrms.web;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DesignationDao;
import com.swati_hrms.dao.EmpExperianceDao;
import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.Designation;
import com.swati_hrms.model.EmployeeExperienceDetails;
import com.swati_hrms.model.EmployeePersonalDetails;

@WebServlet("/addEmpExperienceDetails")
public class AddEmpExperienceDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public AddEmpExperienceDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		if(idStr != null && !idStr.isEmpty()) {
			try {
				int id = Integer.parseInt(idStr);
				EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);
				
				if(employeeDetails != null) {
					request.setAttribute("employeeDetails", employeeDetails);
					
					DesignationDao designationDao = new DesignationDao();
					List<Designation> designation = designationDao.getAllDesignation();
					
					if(designation != null) {
						request.setAttribute("designation", designation);
						request.getRequestDispatcher("Admin/addEmpExpDetails.jsp").forward(request, response);
					}else {
						request.setAttribute("errorMessage", "Designation not found with ID: " + id);
						response.sendRedirect("listRegisterMaster");
					}
					
					
				}else {
					request.setAttribute("errorMessage", "Employee not found with ID: " + id);
					response.sendRedirect("listRegisterMaster");
				}
			}catch(Exception e) {
				request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
				response.sendRedirect("listRegisterMaster");
			}
		}else {
			request.setAttribute("errorMessage", "Employee ID parameter is missing");
			response.sendRedirect("listRegisterMaster");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		if(idStr != null && !idStr.isEmpty()) {
			try {
				int id = Integer.parseInt(idStr);
				EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);
				
				if(employeeDetails != null) {
					
					String compName = request.getParameter("compName");
					String designationIdStr = request.getParameter("designation");
					int designationId = Integer.parseInt(designationIdStr);
				//Parse fromdate string to localDate
					String fromDateStr = request.getParameter("fromDate");
					LocalDate fromDate = LocalDate.parse(fromDateStr);
				//Parse todate string to localDate
					String toDateStr = request.getParameter("toDate");
					LocalDate toDate = LocalDate.parse(toDateStr);
				//	
					String projectDetails = request.getParameter("projectDetails");
					
					DesignationDao designationDao = new DesignationDao();
					Designation designation = designationDao.getDesignationById(designationId);
					
				//Create Employee Experience object
					EmployeeExperienceDetails empExpDetails = new EmployeeExperienceDetails();
					empExpDetails.setEmployeePersonalDetails(employeeDetails);
					empExpDetails.setCompanyName(compName);
					empExpDetails.setDesignation(designation); //save the designation object
					empExpDetails.setDesignationName(empExpDetails.getDesignation().getDesignation());
					empExpDetails.setFromDate(fromDate);
					empExpDetails.setUptoDate(toDate);
					empExpDetails.setProjectDetails(projectDetails);
					empExpDetails.setCreatedBy("Admin");
					
				//Save Employee Experience details
					EmpExperianceDao empExpDao = new EmpExperianceDao();
					empExpDao.saveEmpExperience(empExpDetails);
					
					response.sendRedirect(request.getContextPath() + "/listRegisterMaster");
	                 return; // Stop further execution
				}else {
					request.setAttribute("errorMessage", "Employee not found with ID: " + id);
					response.sendRedirect("listRegisterMaster");
				}
			}catch(Exception e) {
				request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
				response.sendRedirect("listRegisterMaster");
			}
		}else {
			request.setAttribute("errorMessage", "Employee ID parameter is missing");
			response.sendRedirect("listRegisterMaster");
		}
	}

}

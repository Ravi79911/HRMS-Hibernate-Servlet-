package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DegreeDao;
import com.swati_hrms.model.Degree;

/**
 * Servlet implementation class DeleteDegree
 */
@WebServlet("/deleteDegreeMaster")
public class DeleteDegreeMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteDegreeMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 // Get degree ID from request parameter
        String idStr = request.getParameter("id");
        
        if (idStr != null && !idStr.isEmpty()) {
            try {
                int id = Integer.parseInt(idStr);
                
                // Retrieve the Degree from database
                DegreeDao degreeDao = new DegreeDao();
                Degree degree = degreeDao.getDegreeById(id);
                
                if (degree != null) {
                    // Mark the degree as suspended (inactive)
                    degree.setSuspendedStatus(1);
                    
                    // Update the degree in the database
                    degreeDao.updateDegree(degree);
                    
                    response.sendRedirect(request.getContextPath() + "/listDegreeMaster");
                    
                } else {
					response.getWriter().println("Degree with ID " + id + " not found");
                    
                }
            } catch (NumberFormatException e) {
                response.getWriter().println("Invalid degree ID format");
            } catch (Exception e) {
                response.getWriter().println("Error deleting degree: " + e.getMessage());
            }
        } else {
            response.getWriter().println("Degree ID parameter is missing or empty");
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.swati_hrms.web;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Random;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.EmployeePersonalDetails;

/**
 * Servlet implementation class RegisterMaster
 */
@WebServlet("/registerMaster")
public class RegisterMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    
    public RegisterMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			 String fName = request.getParameter("fName");
		        String lName = request.getParameter("lName");
		        String fatherName = request.getParameter("fatherName");
		        String motherName = request.getParameter("motherName");
		        String dobStr = request.getParameter("dob");
		        
		     // Parse date of birth string to LocalDate
		        LocalDate dob = LocalDate.parse(dobStr);
		        
		        String gender = request.getParameter("gender");
		        String email = request.getParameter("email");
		        String phone = request.getParameter("phone");
		        String guardianPhone = request.getParameter("guardianPhone");
		        String pan = request.getParameter("pan");
		        String aadhaar = request.getParameter("aadhaar");
		        String localAddress = request.getParameter("localAddress");
		        String localCity = request.getParameter("localCity");
		        String localState = request.getParameter("localState");
		        String localCountry = request.getParameter("localCountry");
		        String localPin = request.getParameter("localPin");
		        String permanentAddress = request.getParameter("permanentAddress");
		        String permanentCity = request.getParameter("permanentCity");
		        String permanentState = request.getParameter("permanentState");
		        String permanentCountry = request.getParameter("permanentCountry");
		        String permanentPin = request.getParameter("permanentPin");
		        
		     // Generate employee code
		        String employee_code = generateEmployeeCode();
		        
		     // Call Dao from the employee Personal Details dao   
		       EmployeePersonalDetailsDao employeeDao = new EmployeePersonalDetailsDao();
		        
		     //Check if employee with the same code already exists
		        if(employeeDao.employeeExists(employee_code)) {
		        	 request.setAttribute("errorMessage", "Error: Employee with code " + employee_code + " already exists.");
					return;
		        }
		        
		        EmployeePersonalDetails employee = new EmployeePersonalDetails();
		        employee.setEmployee_code(employee_code);
		        employee.setEmployeeFirstName(fName);
		        employee.setEmployeeLastName(lName);
		        employee.setEmployeeFatherName(fatherName);
		        employee.setEmployeeMotherName(motherName);
		        employee.setDOB(dob);
		        employee.setGender(gender);
		        employee.setEmail(email);
		        employee.setMobileNo(phone);
		        employee.setGuardianMobNo(guardianPhone);
		        employee.setPanNo(pan);
		        employee.setAadhaarNo(aadhaar);
		        employee.setLocalAddress(localAddress);
		        employee.setLocalCity(localCity);
		        employee.setLocalCountry(localCountry);
		        employee.setLocalState(localState);
		        employee.setLocalPinCode(localPin);
		        employee.setPermanentAddress(permanentAddress);
		        employee.setPermanentCity(permanentCity);
		        employee.setPermanentCountry(permanentCountry);
		        employee.setPermanentState(permanentState);
		        employee.setPermanentPinCode(permanentPin);
		        employee.setCreatedBy("Admin"); //to be change with userAdmin
		        
		        
		        employeeDao.saveEmployee(employee);
		        
		        response.sendRedirect(request.getContextPath() + "/listRegisterMaster");
		}catch(Exception e) {
			response.getWriter().println("Error saving employee: " + e.getMessage());
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	
	private static final String EMPLOYEE_CODE_PREFIX = "EMP";
	private static final int CODE_LENGTH = 10; // Total length of the employee code
	private static final int RANDOM_PART_LENGTH = CODE_LENGTH - EMPLOYEE_CODE_PREFIX.length(); // Length of the random part

	private static final Random random = new Random();

	private String generateEmployeeCode() {
	    // Generate random part with digits only
	    String randomPart = generateRandomDigits(RANDOM_PART_LENGTH);
	    
	    // Combine prefix and random part
	    return EMPLOYEE_CODE_PREFIX + randomPart;
	}
	
	private String generateRandomDigits(int length) {
	    StringBuilder sb = new StringBuilder(length);
	    for (int i = 0; i < length; i++) {
	        int digit = random.nextInt(10); // Generate a random digit (0-9)
	        sb.append(digit);
	    }
	    return sb.toString();
	}
	
}

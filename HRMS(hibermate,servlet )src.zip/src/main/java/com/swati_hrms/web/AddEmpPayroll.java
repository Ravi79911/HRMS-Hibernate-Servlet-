package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.AddEmployeePayrollDao;
import com.swati_hrms.dao.EmployeeAllowanceDao;
import com.swati_hrms.dao.EmployeeBasicDao;
import com.swati_hrms.dao.EmployeeDeductionDao;
import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.AddEmployeePayroll;
import com.swati_hrms.model.EmployeeAllowance;
import com.swati_hrms.model.EmployeeBasic;
import com.swati_hrms.model.EmployeeDeduction;
import com.swati_hrms.model.EmployeePersonalDetails;

/**
 * Servlet implementation class AddEmpPayroll
 */
@WebServlet("/addEmpPayroll")
public class AddEmpPayroll extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public AddEmpPayroll() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
}

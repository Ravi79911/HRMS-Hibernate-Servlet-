package com.swati_hrms.web;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.EmployeePersonalDetails;


@WebServlet("/editRegisterMaster")
public class EditRegisterMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public EditRegisterMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idParam = request.getParameter("id");
		if(idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);
				
				if(employeeDetails != null) {
					request.setAttribute("employeeDetails", employeeDetails);
					request.getRequestDispatcher("Admin/editRegisterMaster.jsp").forward(request, response);
				}else {
					request.setAttribute("errorMessage", "Employee not found with ID: " + id);
					response.sendRedirect("listRegisterMaster");
				}
			}catch(Exception e) {
				request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
				response.sendRedirect("listRegisterMaster");
			}
		}else {
			// Handle case where no ID parameter is provided
            request.setAttribute("errorMessage", "Employee ID parameter is missing");
            response.sendRedirect("listRegisterMaster"); 
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idParam = request.getParameter("id");
		String fName = request.getParameter("fName");
        String lName = request.getParameter("lName");
        String fatherName = request.getParameter("fatherName");
        String motherName = request.getParameter("motherName");
        String dobStr = request.getParameter("dob");
        
     // Parse date of birth string to LocalDate
        LocalDate dob = LocalDate.parse(dobStr);
        
        String gender = request.getParameter("gender");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String guardianPhone = request.getParameter("guardianPhone");
        String pan = request.getParameter("pan");
        String aadhaar = request.getParameter("aadhaar");
        String localAddress = request.getParameter("localAddress");
        String localCity = request.getParameter("localCity");
        String localState = request.getParameter("localState");
        String localCountry = request.getParameter("localCountry");
        String localPin = request.getParameter("localPin");
        String permanentAddress = request.getParameter("permanentAddress");
        String permanentCity = request.getParameter("permanentCity");
        String permanentState = request.getParameter("permanentState");
        String permanentCountry = request.getParameter("permanentCountry");
        String permanentPin = request.getParameter("permanentPin");
        
        if(idParam != null && !idParam.isEmpty()) {
        	try {
        		int id = Integer.parseInt(idParam);
    			EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
    			EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);
    			
    			if(employeeDetails != null) {
    				employeeDetails.setEmployeeFirstName(fName);
    				employeeDetails.setEmployeeLastName(lName);
    				employeeDetails.setEmployeeFatherName(fatherName);
    				employeeDetails.setEmployeeMotherName(motherName);
    				employeeDetails.setDOB(dob);
    				employeeDetails.setGender(gender);
    				employeeDetails.setEmail(email);
    				employeeDetails.setMobileNo(phone);
    				employeeDetails.setGuardianMobNo(guardianPhone);
    				employeeDetails.setPanNo(pan);
    				employeeDetails.setAadhaarNo(aadhaar);
    				employeeDetails.setLocalAddress(localAddress);
    		        employeeDetails.setLocalCity(localCity);
    		        employeeDetails.setLocalCountry(localCountry);
    		        employeeDetails.setLocalState(localState);
    		        employeeDetails.setLocalPinCode(localPin);
    		        employeeDetails.setPermanentAddress(permanentAddress);
    		        employeeDetails.setPermanentCity(permanentCity);
    		        employeeDetails.setPermanentCountry(permanentCountry);
    		        employeeDetails.setPermanentState(permanentState);
    		        employeeDetails.setPermanentPinCode(permanentPin);
    		        employeeDetails.setCreatedBy("Admin"); //to be change with userAdmin
    		        
    		        employeeDetailsDao.updateEmployee(employeeDetails);
					response.sendRedirect("listRegisterMaster");
    			}else {
    				request.setAttribute("errorMessage", "Employee not found with ID: " + id);
					response.sendRedirect("listRegisterMaster");
    			}
        	}catch(Exception e) {
        		request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
				response.sendRedirect("listRegisterMaster");
        	}
        	
        }else {
        	// Handle case where no ID parameter is provided
            request.setAttribute("errorMessage", "Employee ID parameter is missing");
            response.sendRedirect("listRegisterMaster"); 
        }
	}

}

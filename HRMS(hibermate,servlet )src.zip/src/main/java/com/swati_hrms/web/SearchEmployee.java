package com.swati_hrms.web;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.AddDocuments;
import com.swati_hrms.model.EmployeePersonalDetails;

@WebServlet("/searchEmployee")
public class SearchEmployee extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public SearchEmployee() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String empCode = request.getParameter("empCode");

        EmployeePersonalDetailsDao empPersonalDetailsDao = new EmployeePersonalDetailsDao();
        EmployeePersonalDetails employeeDetails = empPersonalDetailsDao.getEmployeeWithJoiningDetailsByCode(empCode);

        if (employeeDetails != null) {
            request.setAttribute("employeeDetails", employeeDetails);

            // Handle profile image
            String profileImageFilename = null;

            // Loop through documents to find a .jpg file
            for (AddDocuments doc : employeeDetails.getDocuments()) {
                String fileName = doc.getFileName();
                if (fileName != null && fileName.toLowerCase().endsWith(".jpg")) {
                    profileImageFilename = fileName;
                    break;
                }
            }

            System.out.println("Profile Image Filename: " + profileImageFilename);

            // If a .jpg file is found, set the path, otherwise set default
            if (profileImageFilename != null) {
                ServletContext context = getServletContext();
                String uploadPath = context.getRealPath("") + File.separator + "uploads" + File.separator + profileImageFilename;
                File profileImageFile = new File(uploadPath);

                System.out.println("Upload Path: " + uploadPath);
                System.out.println("Profile Image File Exists: " + profileImageFile.exists());

                if (profileImageFile.exists()) {
                    // Use forward slashes in the path for the image URL
                    request.setAttribute("profileImagePath", "uploads/" + profileImageFilename);
                } else {
                    request.setAttribute("profileImagePath", "images/image_sample.jpg"); // Default image if the profile image does not exist
                }
            } else {
                request.setAttribute("profileImagePath", "images/image_sample.jpg"); // Default image if no .jpg profile image is found
            }

            request.getRequestDispatcher("Admin/createLogin.jsp").forward(request, response);
        } else {
            request.setAttribute("errorMessage", "Employee not found or joining details not available for code: " + empCode);
            request.getRequestDispatcher("Admin/createLogin.jsp").forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}

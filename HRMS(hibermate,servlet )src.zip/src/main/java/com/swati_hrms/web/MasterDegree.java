package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DegreeDao;
import com.swati_hrms.model.Degree;

@WebServlet("/masterDegree")
public class MasterDegree extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public MasterDegree() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String degreeName = request.getParameter("degree"); 

        if (degreeName != null && !degreeName.isEmpty()) {
            try {
                Degree degree = new Degree();
                degree.setDegree(degreeName);
                degree.setCreatedBy("Admin"); // Example Name as admin(change when set the user)
                

                DegreeDao degreeDao = new DegreeDao();
                degreeDao.saveDegree(degree);

                response.sendRedirect(request.getContextPath() + "/listDegreeMaster");
                return; // Stop further execution
            } catch (Exception e) {
                response.getWriter().println("Error saving degree: " + e.getMessage());
            }
        } else {
            response.getWriter().println("Degree name parameter is missing or empty");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}

package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DocumentsDao;
import com.swati_hrms.model.Documents;




@WebServlet("/deleteDocumentMaster")
public class DeleteDocumentMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DeleteDocumentMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String idStr = request.getParameter("id");
	        
	        if (idStr != null && !idStr.isEmpty()) {
	            try {
	                int id = Integer.parseInt(idStr);
	                
	                // Retrieve the Degree from database
	                DocumentsDao docsDao = new DocumentsDao();
	                Documents documents = docsDao.getDocumentById(id);
	                
	                if (documents != null) {
	                    // Mark the degree as suspended (inactive)
	                	documents.setSuspendedStatus(1);
	                    
	                    // Update the degree in the database
	                	docsDao.updateDocument(documents);
	                    
	                    response.sendRedirect(request.getContextPath() + "/listDocumentsMaster");
	                    
	                } else {
						response.getWriter().println("Document with ID " + id + " not found");
	                    
	                }
	            } catch (NumberFormatException e) {
	                response.getWriter().println("Invalid document ID format");
	            } catch (Exception e) {
	                response.getWriter().println("Error deleting document: " + e.getMessage());
	            }
	        } else {
	            response.getWriter().println("Document ID parameter is missing or empty");
	        }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

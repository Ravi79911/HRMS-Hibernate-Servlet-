package com.swati_hrms.web;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeeDeductionDao;
import com.swati_hrms.model.EmployeeDeduction;






/**
 * Servlet implementation class EmployeeDelete
 */
@WebServlet("/employeeDeductioncDelete")
public class DeductionDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeductionDelete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		if(idStr != null) {
			long id = Integer.parseInt(idStr);
			
			EmployeeDeductionDao deductionDao = new EmployeeDeductionDao();
			EmployeeDeduction deduction = deductionDao.getDeductionById(id);
			
			if(deduction != null) {
				deduction.setSuspendedStatus(1);
				deduction.setUpdatedDate(new Date());
				deduction.setUpdatedBy("Admin");
				deductionDao.updateDeduction(deduction);
				
				response.sendRedirect(request.getContextPath() + "/employeeDeductionList?success=true");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

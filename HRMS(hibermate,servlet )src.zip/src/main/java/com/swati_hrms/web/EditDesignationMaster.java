package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DesignationDao;
import com.swati_hrms.model.Designation;


@WebServlet("/editDesignationMaster")
public class EditDesignationMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public EditDesignationMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idParam = request.getParameter("id");
		if(idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				DesignationDao designationDao = new DesignationDao();
				Designation designation = designationDao.getDesignationById(id);
				
				if(designation != null) {
					request.setAttribute("designation", designation);
					request.getRequestDispatcher("Admin/editDesignationMaster.jsp").forward(request, response);
				}else {
					request.setAttribute("errorMessage", "Designation not found with ID: " + id);
					response.sendRedirect("listDesignationMaster");
				}
			}catch(NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid designation ID format");
				response.sendRedirect("listDesignationMaster");
			}catch(Exception e) {
				request.setAttribute("errorMessage", "Error fetching designation: " + e.getMessage());
				response.sendRedirect("listDepartmentMaster");
			}
		}else {
			// Handle case where no ID parameter is provided
            request.setAttribute("errorMessage", "Designation ID parameter is missing");
            response.sendRedirect("listDepartmentMaster");  
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idParam = request.getParameter("id");
		String designationName = request.getParameter("designation");
		if(idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				DesignationDao designationDao = new DesignationDao();
				Designation designation = designationDao.getDesignationById(id);
				
				if(designation != null) {
					designation.setDesignation(designationName);
					designationDao.updateDesignation(designation);
					response.sendRedirect("listDesignationMaster");
				}else {
					request.setAttribute("errorMessage", "Designation not found with ID: " + id);
					response.sendRedirect("listDesignationMaster");
				}
			}catch(NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid designation ID format");
				response.sendRedirect("listDesignationMaster");
			}catch(Exception e) {
				request.setAttribute("errorMessage", "Error fetching designation: " + e.getMessage());
				response.sendRedirect("listDepartmentMaster");
			}
		}else {
			// Handle case where no ID parameter is provided
            request.setAttribute("errorMessage", "Designation ID parameter is missing");
            response.sendRedirect("listDepartmentMaster");  
		}
	}

}

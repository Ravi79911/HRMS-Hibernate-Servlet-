package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.RolesDao;
import com.swati_hrms.model.Roles;

@WebServlet("/deleteRoleMaster")
public class DeleteRoleMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	 public DeleteRoleMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
         String idStr = request.getParameter("id");
		
		if(idStr != null && !idStr.isEmpty()) {
			try {
				int id = Integer.parseInt(idStr);
				
				RolesDao rolesDao = new RolesDao();
				Roles roles = rolesDao.getRoleById(id);
				
				if(roles != null) {
					// Mark the stream as suspended (inactive)
					roles.setSuspendedStatus(1);
					
					// Update the stream in the database
					rolesDao.updateRole(roles);
					
					response.sendRedirect(request.getContextPath() + "/listRolesMaster");
				}else {
					response.getWriter().println("Role with ID " + id + " not found");
				}
			}catch(Exception e) {
				e.printStackTrace();
				response.getWriter().println("Error deleting role: " + e.getMessage());
			}
			
		}else {
			response.getWriter().println("Role ID parameter is missing or empty");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

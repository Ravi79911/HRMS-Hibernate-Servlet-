package com.swati_hrms.web;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.dao.RolesDao;
import com.swati_hrms.dao.UserRegistrationDao;
import com.swati_hrms.model.EmployeePersonalDetails;
import com.swati_hrms.model.Roles;
import com.swati_hrms.model.UserRegistration;

@WebServlet("/editEmpLogin")
public class EditEmpLogin extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public EditEmpLogin() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");

        if (idStr != null && !idStr.isEmpty()) {
            try {
                int id = Integer.parseInt(idStr);
                EmployeePersonalDetailsDao empPersonalDetailsDao = new EmployeePersonalDetailsDao();
                EmployeePersonalDetails employeeDetails = empPersonalDetailsDao.getEmployeeWithDetails(id);

                if (employeeDetails != null) {
                    UserRegistrationDao userRegDao = new UserRegistrationDao();
                    UserRegistration user = userRegDao.getUserById(employeeDetails.getId());

                    if (user != null) {
                        request.setAttribute("user", user);

                        RolesDao rolesDao = new RolesDao();
                        List<Roles> roles = rolesDao.getAllRoles();
                        if (roles != null) {
                            request.setAttribute("roles", roles);
                        }
                        request.getRequestDispatcher("Admin/editEmpGenerateLogin.jsp").forward(request, response);
                    } else {
                        request.setAttribute("errorMessage", "User not found for employee ID: " + id);
                        request.getRequestDispatcher("employeeLogin").forward(request, response);
                    }
                } else {
                    request.setAttribute("errorMessage", "Employee not found with ID: " + id);
                    request.getRequestDispatcher("employeeLogin").forward(request, response);
                }
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
                request.getRequestDispatcher("employeeLogin").forward(request, response);
            }
        } else {
            request.setAttribute("errorMessage", "Employee ID parameter is missing");
            request.getRequestDispatcher("employeeLogin").forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");

        if (idStr != null && !idStr.isEmpty()) {
            try {
                int id = Integer.parseInt(idStr);
                EmployeePersonalDetailsDao empPersonalDetailsDao = new EmployeePersonalDetailsDao();
                EmployeePersonalDetails employeeDetails = empPersonalDetailsDao.getEmployeeWithDetails(id);

                if (employeeDetails != null) {
                    String username = request.getParameter("username");
                    String newPassword = request.getParameter("password");
                    String roleStr = request.getParameter("roles");

                    if (roleStr == null || roleStr.isEmpty() || newPassword == null || newPassword.isEmpty()) {
                        request.setAttribute("errorMessage", "Role or Password cannot be empty");
                        request.getRequestDispatcher("Admin/editEmpGenerateLogin.jsp").forward(request, response);
                        return;
                    }

                    int roleId = Integer.parseInt(roleStr);

                    RolesDao rolesDao = new RolesDao();
                    Roles roles = rolesDao.getRoleById(roleId);

                    UserRegistrationDao userRegDao = new UserRegistrationDao();
                    UserRegistration user = userRegDao.getUserById(employeeDetails.getId());

                    if (user == null) {
                        // Create new user
                        user = new UserRegistration();
                        user.setEmployeePersonalDetails(employeeDetails);
                        user.setCreatedBy("Admin"); // to be updated with user login
                        user.setUpdatedBy("Admin"); // to be updated with user login
                    } else {
                        // Update existing user
                        user.setUpdatedBy("Admin"); // to be updated with user login
                        user.setLastPassword(user.getPassword()); // Save current password as last password
                    }

                    user.setUserName(username);
                    user.setPassword(newPassword); // Save new password
                    user.setRole(roles); // Save the roles object
                    user.setRoleName(user.getRole().getRoleName());

                    userRegDao.UpdateUser(user);

                    response.sendRedirect(request.getContextPath() + "/employeeLogin");
                } else {
                    request.setAttribute("errorMessage", "Employee not found with ID: " + id);
                    request.getRequestDispatcher("employeeLogin").forward(request, response);
                }
            } catch (Exception e) {
                request.setAttribute("errorMessage", "Error updating employee: " + e.getMessage());
                request.getRequestDispatcher("employeeLogin").forward(request, response);
            }
        } else {
            request.setAttribute("errorMessage", "Employee ID parameter is missing");
            request.getRequestDispatcher("employeeLogin").forward(request, response);
        }
    }
}

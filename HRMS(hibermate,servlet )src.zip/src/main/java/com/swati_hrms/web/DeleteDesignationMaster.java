package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DesignationDao;
import com.swati_hrms.model.Designation;


@WebServlet("/deleteDesignationMaster")
public class DeleteDesignationMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DeleteDesignationMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		
		if(idStr != null && !idStr.isEmpty()) {
			try {
				int id = Integer.parseInt(idStr);
				
				DesignationDao designationDao = new DesignationDao();
				Designation designation = designationDao.getDesignationById(id);
				
				if(designation != null) {
					// Mark the designation as suspended (inactive)
					designation.setSuspendedStatus(1);
					
					// Update the designation in the database
					designationDao.updateDesignation(designation);
					
					response.sendRedirect(request.getContextPath() + "/listDesignationMaster");
				}else {
					response.getWriter().println("Designation with ID " + id + " not found");
				}
			}catch(Exception e) {
				e.printStackTrace();
				response.getWriter().println("Error deleting designation: " + e.getMessage());
			}
		}else {
			response.getWriter().println("Designation ID parameter is missing or empty");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

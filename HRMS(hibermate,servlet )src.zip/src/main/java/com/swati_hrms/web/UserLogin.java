package com.swati_hrms.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.swati_hrms.dao.UserRegistrationDao;
import com.swati_hrms.model.UserRegistration;
@WebServlet("/userlogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
//    public UserLogin() {
//        super();
//        // TODO Auto-generated constructor stub
//    }
    
    private UserRegistrationDao userRegistrationDao;
    
    public void init() {
    	userRegistrationDao = new UserRegistrationDao();
    }

	
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	try {
        String userName = request.getParameter("userName");
        String password = request.getParameter("password");

        UserRegistration user = userRegistrationDao.validateUser(userName, password);

        if (user != null) {
            HttpSession session = request.getSession();
            //session.setAttribute("user", user);
            session.setAttribute("userName", user.getUserName()); // user.getUserName() gets the user's name
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
    		dispatcher.forward(request, response);
            //response.sendRedirect("/index.jsp"); // Redirect to home page if login is successful
        } else {
            request.setAttribute("error", "Invalid Username or Password");
            RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
            dispatcher.forward(request, response);
        }
    	} catch(Exception e) {
    		request.setAttribute("error", "An internal error occurred: " + e.getMessage());
    	    e.printStackTrace();
    	    RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
    	    dispatcher.forward(request, response);
    	}
    }

}

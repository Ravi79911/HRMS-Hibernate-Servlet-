package com.swati_hrms.web;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeeAllowanceDao;
import com.swati_hrms.model.EmployeeAllowance;


/**
 * Servlet implementation class EmployeeDelete
 */
@WebServlet("/employeeAllowanceDelete")
public class AllowanceDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AllowanceDelete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		if(idStr != null) {
			long id = Integer.parseInt(idStr);
			
			EmployeeAllowanceDao allowanceDao = new EmployeeAllowanceDao();
			EmployeeAllowance allowance = allowanceDao.getAllowanceById(id);
			
			if(allowance != null) {
				allowance.setSuspendedStatus(1);
				allowance.setUpdatedDate(new Date());
				allowance.setUpdatedBy("Admin");
				allowanceDao.updateAllowance(allowance);
				
				 response.sendRedirect(request.getContextPath() + "/employeeAllowanceList?success=true");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

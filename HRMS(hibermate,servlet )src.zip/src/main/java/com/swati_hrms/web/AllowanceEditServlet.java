package com.swati_hrms.web;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeeAllowanceDao;
import com.swati_hrms.model.EmployeeAllowance;







/**
 * Servlet implementation class EmployeeEdit
 */
@WebServlet("/editEmployeeAllowance")
public class AllowanceEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public AllowanceEditServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String idStr = request.getParameter("id");
		if(idStr != null) {
			long id = Integer.parseInt(idStr);
			
			EmployeeAllowanceDao allowanceDAO = new EmployeeAllowanceDao();
			EmployeeAllowance allowance = allowanceDAO.getAllowanceById(id);
		
			System.out.println(allowance);
			        request.setAttribute("allowance", allowance);
			        
              
	            request.getRequestDispatcher("Admin/editEmployeeAllowance.jsp").forward(request, response);
			 }
			 }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 long id = Long.parseLong(request.getParameter("id"));
	        String allowanceName = request.getParameter("allowanceName");
	        String allowanceValue = request.getParameter("allowanceValue");
	        String calculationType = request.getParameter("calculationType");

	        try {
	           
	        	 EmployeeAllowanceDao allowanceDAO=new EmployeeAllowanceDao();
	            EmployeeAllowance allowance = allowanceDAO.getAllowanceById(id);
	            allowance.setAllowanceName(allowanceName);
	            allowance.setAllowanceValue(Double.parseDouble(allowanceValue));
	            allowance.setCalculationType(calculationType);
	            allowance.setUpdatedDate(new Date());
	            allowance.setUpdatedBy("Admin");
	            allowanceDAO.updateAllowance(allowance);
	       
	        } catch (Exception e) {
	           
	            e.printStackTrace();
	        } 

	        response.sendRedirect(request.getContextPath() + "/employeeAllowanceList?success=true");
	    }
	}
	

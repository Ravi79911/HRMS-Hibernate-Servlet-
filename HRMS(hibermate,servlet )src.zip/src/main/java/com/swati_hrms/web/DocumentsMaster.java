package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DocumentsDao;
import com.swati_hrms.model.Documents;




@WebServlet("/documentsMaster")
public class DocumentsMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DocumentsMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String docName = request.getParameter("docs"); 

        if (docName != null && !docName.isEmpty()) {
            try {
                Documents documents = new Documents();
                documents.setDocName(docName);
                documents.setCreatedBy("Admin"); // Example Name as admin(change when set the user)
                

                DocumentsDao docDao = new DocumentsDao();
                docDao.saveDocument(documents);

                response.sendRedirect(request.getContextPath() + "/listDocumentsMaster");
                return; // Stop further execution
            } catch (Exception e) {
                response.getWriter().println("Error saving degree: " + e.getMessage());
            }
        } else {
            response.getWriter().println("Degree name parameter is missing or empty");
        }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

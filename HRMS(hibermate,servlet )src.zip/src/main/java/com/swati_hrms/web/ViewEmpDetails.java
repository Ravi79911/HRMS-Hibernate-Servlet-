package com.swati_hrms.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.EmployeePersonalDetails;

@WebServlet("/viewEmpDetails")
public class ViewEmpDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ViewEmpDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");

		if (idStr != null && !idStr.isEmpty()) {
			int id = Integer.parseInt(idStr);
			EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
			EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeWithDetails(id);

			if (employeeDetails != null) {
				request.setAttribute("employeeDetails", employeeDetails);

				request.getRequestDispatcher("Admin/viewEmployeeDetails.jsp").forward(request, response);

			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

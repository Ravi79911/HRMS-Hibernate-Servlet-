package com.swati_hrms.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeeDeductionDao;
import com.swati_hrms.model.EmployeeDeduction;


@WebServlet("/employeeDeductionList")
public class EmployeeDeductionList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public EmployeeDeductionList() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 EmployeeDeductionDao deductionDAO = new EmployeeDeductionDao();
         List<EmployeeDeduction> deductions = deductionDAO.getAllDeduction();
         
         request.setAttribute("deductions", deductions);
	     request.getRequestDispatcher("Admin/employeeDeductionList.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

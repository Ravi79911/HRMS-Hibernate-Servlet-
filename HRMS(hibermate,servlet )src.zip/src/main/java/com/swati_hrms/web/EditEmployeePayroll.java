package com.swati_hrms.web;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.OptimisticLockException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;

import com.swati_hrms.dao.AddEmployeePayrollDao;
import com.swati_hrms.dao.EmployeeAllowanceDao;
import com.swati_hrms.dao.EmployeeBasicDao;
import com.swati_hrms.dao.EmployeeDeductionDao;
import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.AddEmployeePayroll;
import com.swati_hrms.model.EmployeeAllowance;
import com.swati_hrms.model.EmployeeBasic;
import com.swati_hrms.model.EmployeeDeduction;
import com.swati_hrms.model.EmployeePersonalDetails;
import com.swati_hrms.util.HibernateUtil;

/**
 * Servlet implementation class EditEmployeePayroll
 */
@WebServlet("/editEmployeePayroll")
public class EditEmployeePayroll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EditEmployeePayroll() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idStr = request.getParameter("id");

		if (idStr != null && !idStr.isEmpty()) {
			int id = Integer.parseInt(idStr);

			EmployeePersonalDetailsDao employeeDao = new EmployeePersonalDetailsDao();
			EmployeePersonalDetails employeeDetails = employeeDao.getEmployeeWithDetails(id);

			if (employeeDetails != null) {
				request.setAttribute("employees", employeeDetails);

				if (employeeDetails != null) {
					request.setAttribute("employees", employeeDetails);

					EmployeeBasicDao basicDao = new EmployeeBasicDao();
					List<EmployeeBasic> basics = basicDao.getAllBasics();
					if (basics != null) {
						request.setAttribute("basics", basics);
						
						// Get existing scales for the employee
					    Set<String> existingScaleNames = new HashSet<>();
					    for (AddEmployeePayroll payroll : employeeDetails.getEmployeePayroll()) {
					        for (EmployeeBasic basic : payroll.getBasics()) {
					            existingScaleNames.add(basic.getScaleName());
					        }
					    }
					    request.setAttribute("existingScaleNames", existingScaleNames);
					}

					EmployeeDeductionDao deductionDao = new EmployeeDeductionDao();
					List<EmployeeDeduction> deductions = deductionDao.getAllDeduction();
					if (deductions != null) {
						request.setAttribute("deductions", deductions);
						
						Set<String> existingDeductionNames = new HashSet<>();
						
						for (AddEmployeePayroll payroll : employeeDetails.getEmployeePayroll()) {
					        for (EmployeeDeduction deduction : payroll.getDeductions()) {
					        	existingDeductionNames.add(deduction.getDeductionName());
					        }
					    }
					    request.setAttribute("existingDeductionNames", existingDeductionNames);
						
					}

					EmployeeAllowanceDao allowanceDao = new EmployeeAllowanceDao();
					List<EmployeeAllowance> allowances = allowanceDao.getAllAllowance();
					if (allowances != null) {
						request.setAttribute("allowances", allowances);
						
                        Set<String> existingAllowanceNames = new HashSet<>();
						
						for (AddEmployeePayroll payroll : employeeDetails.getEmployeePayroll()) {
					        for (EmployeeAllowance allowance : payroll.getAllowances()) {
					        	existingAllowanceNames.add(allowance.getAllowanceName());
					        }
					    }
					    request.setAttribute("existingAllowanceNames", existingAllowanceNames);
					}
					
					

					request.getRequestDispatcher("Admin/editEmployeePayroll.jsp").forward(request, response);

				}

			} else {
				request.setAttribute("errorMessage", "Employee not found with ID: " + id);
				response.sendRedirect("listRegisterMaster");
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	        throws ServletException, IOException {
	    try {
	        // Retrieve employee ID
	        String idStr = request.getParameter("id");
	        if (idStr == null || idStr.isEmpty()) {
	            response.sendRedirect("listRegisterMaster?error=InvalidEmployeeId");
	            return;
	        }

	        int employeeId;
	        try {
	            employeeId = Integer.parseInt(idStr);
	        } catch (NumberFormatException e) {
	            response.sendRedirect("listRegisterMaster?error=InvalidEmployeeId");
	            return;
	        }

	        // Open session
	        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
	            session.beginTransaction();

	            EmployeePersonalDetailsDao employeeDao = new EmployeePersonalDetailsDao();
	            EmployeePersonalDetails employee = employeeDao.getEmployeeWithDetails(employeeId);
	            if (employee == null) {
	                response.sendRedirect("listRegisterMaster?error=EmployeeNotFound");
	                return;
	            }

	            // Retrieve form data
	            String[] scaleNames = request.getParameterValues("scaleName[]");
	            String[] scaleValues = request.getParameterValues("scaleValue[]");
	            String[] allowanceNames = request.getParameterValues("allowanceName[]");
	            String[] allowanceValues = request.getParameterValues("allowanceValue[]");
	            String[] deductionNames = request.getParameterValues("deductionName[]");
	            String[] deductionValues = request.getParameterValues("deductionValue[]");

	            if (scaleNames == null || scaleValues == null || allowanceNames == null || allowanceValues == null || deductionNames == null || deductionValues == null) {
	                response.sendRedirect("listRegisterMaster?error=InvalidFormData");
	                return;
	            }

	            EmployeeBasicDao basicDao = new EmployeeBasicDao();
	            EmployeeAllowanceDao allowanceDao = new EmployeeAllowanceDao();
	            EmployeeDeductionDao deductionDao = new EmployeeDeductionDao();
	            AddEmployeePayrollDao payrollDao = new AddEmployeePayrollDao();

	            // Fetch existing payroll entry
	            AddEmployeePayroll payroll = payrollDao.getEmpPayrollById(employeeId);
	            if (payroll == null) {
	                response.sendRedirect("listRegisterMaster?error=PayrollNotFound");
	                return;
	            }

	            // Clear existing associations before updating
	            payroll.getBasics().clear();
	            payroll.getAllowances().clear();
	            payroll.getDeductions().clear();

	            // Process scales
	            for (int i = 0; i < scaleNames.length; i++) {
	                try {
	                    String scaleName = scaleNames[i];
	                    Double scaleValue = Double.parseDouble(scaleValues[i]);
	                    EmployeeBasic basic = basicDao.getBasicByScaleNameAndValue(scaleName, scaleValue);
	                    if (basic != null) {
	                        payroll.getBasics().add(basic);
	                    }
	                } catch (NumberFormatException e) {
	                    e.printStackTrace();
	                } catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }

	            // Process allowances
	            for (int i = 0; i < allowanceNames.length; i++) {
	                try {
	                    String allowanceName = allowanceNames[i];
	                    Double allowanceValue = Double.parseDouble(allowanceValues[i]);
	                    EmployeeAllowance allowance = allowanceDao.getBasicByAllowanceNameAndValue(allowanceName, allowanceValue);
	                    if (allowance != null) {
	                        payroll.getAllowances().add(allowance);
	                    }
	                } catch (NumberFormatException e) {
	                    e.printStackTrace();
	                } catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }

	            // Process deductions
	            for (int i = 0; i < deductionNames.length; i++) {
	                try {
	                    String deductionName = deductionNames[i];
	                    Double deductionValue = Double.parseDouble(deductionValues[i]);
	                    EmployeeDeduction deduction = deductionDao.getBasicByDeductionNameAndValue(deductionName, deductionValue);
	                    if (deduction != null) {
	                        payroll.getDeductions().add(deduction);
	                    }
	                } catch (NumberFormatException e) {
	                    e.printStackTrace();
	                } catch (Exception e) {
	                    e.printStackTrace();
	                }
	            }

	            // Save the updated payroll entry
	            try {
	                payrollDao.updateEmployeePayroll(payroll);
	                session.getTransaction().commit();
	            } catch (OptimisticLockException e) {
	                // Handle optimistic locking failure
	                e.printStackTrace();
	                response.sendRedirect("listRegisterMaster?error=OptimisticLockException");
	                return;
	            } catch (Exception e) {
	                // Handle other potential exceptions
	                e.printStackTrace();
	                response.sendRedirect("listRegisterMaster?error=InternalServerError");
	                return;
	            }
	        }
	        response.sendRedirect("listRegisterMaster?success=DataSaved");
	    } catch (Exception e) {
	        e.printStackTrace(); // Consider using a logging framework
	        response.sendRedirect("listRegisterMaster?error=InternalServerError");
	    }
	}

}

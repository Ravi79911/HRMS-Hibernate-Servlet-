package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DegreeDao;
import com.swati_hrms.model.Degree;

@WebServlet("/editDegreeMaster")
public class EditDegreeMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EditDegreeMaster() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				DegreeDao degreeDao = new DegreeDao();
				Degree degree = degreeDao.getDegreeById(id);
				if (degree != null) {
					request.setAttribute("degree", degree);
					request.getRequestDispatcher("Admin/editDegreeMaster.jsp").forward(request, response);
				} else {
					// Handle case where degree with given ID is not found
					request.setAttribute("errorMessage", "Degree not found with ID: " + id);
					response.sendRedirect("listDegreeMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid degree ID format");
				response.sendRedirect("listDegreeMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error fetching degree: " + e.getMessage());
				response.sendRedirect("listDegreeMaster");
			}
		} else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "Degree ID parameter is missing");
			response.sendRedirect("listDegreeMaster");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		String degreeName = request.getParameter("degree");

		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				DegreeDao degreeDao = new DegreeDao();
				Degree degree = degreeDao.getDegreeById(id);
				if (degree != null) {
					degree.setDegree(degreeName); // Update degree name
					degreeDao.updateDegree(degree); // Update degree in database
					// Redirect to list page after update
					response.sendRedirect("listDegreeMaster");
				} else {
					// Handle case where degree with given ID is not found
					request.setAttribute("errorMessage", "Degree not found with ID: " + id);
					response.sendRedirect("listDegreeMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid degree ID format");
				response.sendRedirect("listDegreeMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error updating degree: " + e.getMessage());
				response.sendRedirect("listDegreeMaster");
			}
		} else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "Degree ID parameter is missing");
			response.sendRedirect("listDegreeMaster");
		}
	}

}

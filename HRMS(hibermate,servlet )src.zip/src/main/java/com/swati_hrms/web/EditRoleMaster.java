package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.RolesDao;
import com.swati_hrms.model.Roles;

@WebServlet("/editRoleMaster")
public class EditRoleMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EditRoleMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				RolesDao rolesDao = new RolesDao();
				Roles roles = rolesDao.getRoleById(id);
				if (roles != null) {
					request.setAttribute("roles", roles);
					request.getRequestDispatcher("Admin/editRoleMaster.jsp").forward(request, response);
				} else {
					// Handle case where degree with given ID is not found
					request.setAttribute("errorMessage", "Role not found with ID: " + id);
					response.sendRedirect("listRolesMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid role ID format");
				response.sendRedirect("listRolesMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error fetching role: " + e.getMessage());
				response.sendRedirect("listRolesMaster");
			}
		} else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "Role ID parameter is missing");
			response.sendRedirect("listRolesMaster");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		String roleName = request.getParameter("roleName");

		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				RolesDao rolesDao = new RolesDao();
				Roles roles = rolesDao.getRoleById(id);
				if (roles != null) {
					roles.setRoleName(roleName);// Update degree name
					rolesDao.updateRole(roles); // Update degree in database
					// Redirect to list page after update
					response.sendRedirect("listRolesMaster");
				} else {
					// Handle case where degree with given ID is not found
					request.setAttribute("errorMessage", "Role not found with ID: " + id);
					response.sendRedirect("listRolesMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid role ID format");
				response.sendRedirect("listRolesMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error updating role: " + e.getMessage());
				response.sendRedirect("listRolesMaster");
			}
		} else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "Role ID parameter is missing");
			response.sendRedirect("listRolesMaster");
		}
	}

}

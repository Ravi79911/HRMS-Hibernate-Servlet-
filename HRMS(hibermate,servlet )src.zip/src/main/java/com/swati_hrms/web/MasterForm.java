package com.swati_hrms.web;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/")
public class MasterForm extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public MasterForm() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		

		try {
			switch (action) {
			case "/register":
				showRegForm(request, response);
				break;
			case "/degree":
				showDegreeForm(request, response);
				break;
			case "/department":
				showDepartmentForm(request, response);
				break;
			case "/designation":
				showDesignationForm(request, response);
				break;
			case "/skills":
				showSkillsForm(request, response);
				break;
			case "/streams":
				showStreamsForm(request, response);
				break;
			case "/documents":
				showDocumentForm(request, response);
				break;
			case "/roles":
				showRoleForm(request, response);
				break;
			case "/addEmployeeBasic":
				showEmployeeBasicForm(request, response);
				break;
			case "/addEmployeeAllowance":
				showEmployeeAllowanceForm(request, response);
				break;
			case "/addEmployeeDeduction":
				showEmployeeDeductionForm(request, response);
				break;
			case "/login":
				showLoginForm(request, response);
				break;
			case "/forgot-password":
				showForgotPassword(request, response);
				break;
			case "/reset-password":
				showResetPassword(request, response);
				break;
			default:
				//showRegForm(request, response);
				showDashboard(request, response);
				break;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new ServletException(ex);
		}
	}
	private void showRegForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/registerMaster.jsp");
		dispatcher.forward(request, response);
	}
	private void showDashboard(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
	}
	private void showDegreeForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/degreeMaster.jsp");
		dispatcher.forward(request, response);
	}
	private void showDepartmentForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/departmentMaster.jsp");
		dispatcher.forward(request, response);
	}
	private void showDesignationForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/designationMaster.jsp");
		dispatcher.forward(request, response);
	}
	private void showSkillsForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/keySkillsMaster.jsp");
		dispatcher.forward(request, response);
	}
	private void showStreamsForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/streamsMaster.jsp");
		dispatcher.forward(request, response);
	}
	private void showDocumentForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/documentMaster.jsp");
		dispatcher.forward(request, response);
	}
	
	private void showRoleForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/roleMaster.jsp");
		dispatcher.forward(request, response);
	}
	private void showEmployeeBasicForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/addEmployeeBasic.jsp");
		dispatcher.forward(request, response);
	}
	private void showEmployeeAllowanceForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/addEmployeeAllowance.jsp");
		dispatcher.forward(request, response);
	}
	private void showEmployeeDeductionForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/addEmployeeDeduction.jsp");
		dispatcher.forward(request, response);
	}
	private void showLoginForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
		dispatcher.forward(request, response);
	}
	private void showForgotPassword(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/forgot-password.jsp");
		dispatcher.forward(request, response);
	}
	private void showResetPassword(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/reset-password.jsp");
		dispatcher.forward(request, response);
	}
}



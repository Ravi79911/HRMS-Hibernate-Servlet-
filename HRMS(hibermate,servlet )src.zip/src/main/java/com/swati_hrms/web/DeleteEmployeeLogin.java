package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.UserRegistrationDao;
import com.swati_hrms.model.UserRegistration;

@WebServlet("/deleteEmployeeLogin")
public class DeleteEmployeeLogin extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    public DeleteEmployeeLogin() {
    	super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get employee id from request
        String id = request.getParameter("id");
        if (id != null && !id.isEmpty()) {
            try {
                // Parse the employee ID and call DAO to delete the user
                int employeeId = Integer.parseInt(id);
                UserRegistrationDao userDao = new UserRegistrationDao();
                UserRegistration user = userDao.getUserById(employeeId);
                
                System.out.println("User Id is: "+ employeeId);
                System.out.println("Suspended Status Before Delete is: "+ user.getSuspendedStatus());
                
                if(user != null) {
                	//Mark the userLogin as suspended (inactive)
                	user.setSuspendedStatus(1);
                	
                	userDao.UpdateUser(user);
                	
                	System.out.println("Suspended Status After Delete is: "+ user.getSuspendedStatus());
                	
                	response.sendRedirect(request.getContextPath() + "/employeeLogin");
                }else {
                	response.getWriter().println("Username with Id " + employeeId + " not found");
                }
                
                // Perform deletion
                
            } catch (NumberFormatException e) {
                e.printStackTrace();
                //response.sendRedirect("listEmployeeLogin.jsp?status=error");
                response.getWriter().println("Error deleting Username: " + e.getMessage());
            }
        } else {
            // If no valid ID, redirect with an error
            //response.sendRedirect("listEmployeeLogin.jsp?status=error");
        	response.getWriter().println("Employee ID parameter is missing or empty");
        }
    }
}

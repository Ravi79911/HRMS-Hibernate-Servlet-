package com.swati_hrms.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.AddKeySkillsDao;
import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.dao.KeySkillsDao;
import com.swati_hrms.model.AddKeySkill;
import com.swati_hrms.model.EmployeePersonalDetails;
import com.swati_hrms.model.KeySkills;

@WebServlet("/addKeySkills")
public class AddKeySkills extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public AddKeySkills() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idParam = request.getParameter("id");
        if (idParam != null && !idParam.isEmpty()) {
            try {
                int id = Integer.parseInt(idParam);
                EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
                EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);

                if (employeeDetails != null) {
                    request.setAttribute("employeeDetails", employeeDetails);

                    KeySkillsDao keySkillsDao = new KeySkillsDao();
                    List<KeySkills> keySkills = keySkillsDao.getAllKeySkills();
                    if (keySkills != null) {
                        request.setAttribute("keySkills", keySkills);
                        request.getRequestDispatcher("Admin/addKeySkill.jsp").forward(request, response);
                    } else {
                        request.setAttribute("errorMessage", "Skills not found with ID: " + id);
                        response.sendRedirect("listRegisterMaster");
                    }
                } else {
                    request.setAttribute("errorMessage", "Employee not found with ID: " + id);
                    response.sendRedirect("listRegisterMaster");
                }
            } catch (Exception e) {
                request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
                response.sendRedirect("listRegisterMaster");
            }
        } else {
            request.setAttribute("errorMessage", "Employee ID parameter is missing");
            response.sendRedirect("listRegisterMaster");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idParam = request.getParameter("id");
        
           if (idParam != null && !idParam.isEmpty()) {
            try {
                int id = Integer.parseInt(idParam);
                EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
                EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);

                if (employeeDetails != null) {
                      String keySkillIdStr = request.getParameter("keySkills");
                      int keySkillId = Integer.parseInt(keySkillIdStr);
                      
                      String expMonthsStr = request.getParameter("expMonths");
                      long empMonths = Integer.parseInt(expMonthsStr);
                      
                    // Fetch keySkill details from dao class  
                      KeySkillsDao skillDao = new KeySkillsDao();
                      KeySkills skills =  skillDao.getKeySkillsById(keySkillId);
                      
                      AddKeySkill addSkill = new AddKeySkill();
                      addSkill.setEmployeePersonalDetails(employeeDetails);
                      addSkill.setKeySkills(skills); //create skill object
                      addSkill.setKeySkillName(addSkill.getKeySkills().getSkillName());
                      addSkill.setExpMonths(empMonths);
                      addSkill.setCreatedBy("Admin"); //to be replace by current User
                     
                    
                    AddKeySkillsDao addSkillDao = new AddKeySkillsDao();
                    addSkillDao.saveSkill(addSkill);
                   

                    response.sendRedirect(request.getContextPath() + "/listRegisterMaster");
                }
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("listRegisterMaster");
            }
        } else {
            response.sendRedirect("listRegisterMaster");
        }
    }
}

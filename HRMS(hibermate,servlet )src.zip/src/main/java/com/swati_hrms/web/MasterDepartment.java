package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DepartmentDao;
import com.swati_hrms.model.Department;


@WebServlet("/masterDepartment")
public class MasterDepartment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public MasterDepartment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String departmentName = request.getParameter("department");
		
		if(departmentName != null && !departmentName.isEmpty()) {
			try {
				Department department = new Department();
				department.setDepartment(departmentName);
				department.setCreatedBy("Admin"); //to be replace with username
				
				DepartmentDao departmengtDao = new DepartmentDao();
				departmengtDao.saveDepartment(department);
				
				response.sendRedirect(request.getContextPath() + "/listDepartmentMaster");
                return; // Stop further execution
			} catch(Exception e) {
				 response.getWriter().println("Error saving department: " + e.getMessage());
			}
		}else {
			response.getWriter().println("Degree name parameter is missing or empty");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

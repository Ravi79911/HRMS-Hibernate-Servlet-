package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DocumentsDao;
import com.swati_hrms.model.Documents;


@WebServlet("/editDocumentMaster")
public class EditDocumentMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public EditDocumentMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idParam = request.getParameter("id");
		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				DocumentsDao docsDao = new DocumentsDao();
				Documents document = docsDao.getDocumentById(id);
				if (document != null) {
					request.setAttribute("document", document);
					request.getRequestDispatcher("Admin/editDocumentMaster.jsp").forward(request, response);
				} else {
					// Handle case where degree with given ID is not found
					request.setAttribute("errorMessage", "Document not found with ID: " + id);
					response.sendRedirect("listDocumentsMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid document ID format");
				response.sendRedirect("listDocumentsMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error fetching document: " + e.getMessage());
				response.sendRedirect("listDocumentsMaster");
			}
		} else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "Document ID parameter is missing");
			response.sendRedirect("listDocumentsMaster");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idParam = request.getParameter("id");
		String docName = request.getParameter("docs");

		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				DocumentsDao docsDao = new DocumentsDao();
				Documents document = docsDao.getDocumentById(id);
				if (document != null) {
					document.setDocName(docName); // Update degree name
					docsDao.updateDocument(document); // Update degree in database
					// Redirect to list page after update
					response.sendRedirect("listDocumentsMaster");
				} else {
					// Handle case where degree with given ID is not found
					request.setAttribute("errorMessage", "Document not found with ID: " + id);
					response.sendRedirect("listDocumentsMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid document ID format");
				response.sendRedirect("listDocumentsMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error updating document: " + e.getMessage());
				response.sendRedirect("listDocumentsMaster");
			}
		} else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "Document ID parameter is missing");
			response.sendRedirect("listDocumentsMaster");
		}
	}
	
}



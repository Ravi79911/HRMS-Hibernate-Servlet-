package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.KeySkillsDao;
import com.swati_hrms.model.KeySkills;


@WebServlet("/deleteKeySkillMaster")
public class DeleteKeySkillMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteKeySkillMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		 if(idStr != null && !idStr.isEmpty()) {
		   try {
			 int id = Integer.parseInt(idStr);
			 
			 KeySkillsDao keySkillsDao = new KeySkillsDao();
			 KeySkills keySkills = keySkillsDao.getKeySkillsById(id);
			 
			 if(keySkills != null) {
				// Mark the degree as suspended (inactive)
				 keySkills.setSuspendedStatus(1);
                 
                 // Update the degree in the database
				 keySkillsDao.updateKeySkills(keySkills);
                 
                 response.sendRedirect(request.getContextPath() + "/listKeySkillsMaster");
                 
			 }else {
				 response.getWriter().println("Skill with ID " + id + " not found");
			 }
			 }catch(Exception e) {
				 response.getWriter().println("Error deleting degree: " + e.getMessage());
			 }
		 }else {
			 response.getWriter().println("Skill ID parameter is missing or empty");
		 }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.swati_hrms.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.model.EmployeeDeduction;
import com.swati_hrms.util.HibernateUtil;



/**
 * Servlet implementation class EmployeeBasicServlet
 */
@WebServlet("/addEmpDeduction")
public class DeductionRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeductionRegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 String[] deductionName = request.getParameterValues("deductionName");
	        String[] deductionValues = request.getParameterValues("deductionValue");
	        String[] deductionCalculationTypes = request.getParameterValues("deductionCalculationTypes");

	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction tx = session.beginTransaction();

	        try {
	            List<EmployeeDeduction> deductionList = new ArrayList<>();
	            for (int i = 0; i < deductionName.length; i++) {
	                EmployeeDeduction deduction = new EmployeeDeduction();
	                deduction.setDeductionName(deductionName[i]);
	                deduction.setDeductionValue(Double.parseDouble(deductionValues[i]));
	                deduction.setCalculationType(deductionCalculationTypes[i]);
	                deduction.setCreatedDate(new Date());
	                deductionList.add(deduction);
	                session.save(deduction);
	            }
	            tx.commit();
	            response.sendRedirect(request.getContextPath() + "/employeeDeductionList?success=true");
	        } catch (Exception e) {
	            if (tx != null) tx.rollback();
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    }

	    
	}

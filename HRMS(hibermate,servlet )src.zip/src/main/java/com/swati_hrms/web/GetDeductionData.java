package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.swati_hrms.dao.EmployeeBasicDao;
import com.swati_hrms.dao.EmployeeDeductionDao;
import com.swati_hrms.model.EmployeeBasic;
import com.swati_hrms.model.EmployeeDeduction;

/**
 * Servlet implementation class GetDeductionData
 */
@WebServlet("/getDeductionData")
public class GetDeductionData extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetDeductionData() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String deductionName = request.getParameter("deductionName");

	        if (deductionName != null && !deductionName.isEmpty()) {
	            EmployeeDeductionDao deductionDao = new EmployeeDeductionDao();
	            EmployeeDeduction deduction = deductionDao.getDeductionByName(deductionName);
	            
	            response.setContentType("application/json");
	            response.setCharacterEncoding("UTF-8");

	            if (deduction != null) {
	                // Convert the scale object to JSON
	                String json = new Gson().toJson(deduction);
	                response.getWriter().write(json);
	            } else {
	                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
	                response.getWriter().write("{\"error\":\"Scale not found\"}");
	            }
	        } else {
	            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	            response.getWriter().write("{\"error\":\"Invalid deduction name\"}");
	        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

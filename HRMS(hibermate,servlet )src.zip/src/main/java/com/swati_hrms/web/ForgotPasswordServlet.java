package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.UserRegistrationDao;
import com.swati_hrms.model.UserRegistration;
import com.swati_hrms.util.EmailUtility;

@WebServlet("/forgotPassword")
public class ForgotPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private UserRegistrationDao userRegistrationDao;

    public void init() {
        userRegistrationDao = new UserRegistrationDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        UserRegistration user = userRegistrationDao.findUserByEmail(email);
        
        try {
        if (user != null) {
            // Generate a unique reset token and save it in the user model (this could be a UUID or random string)
            String resetToken = java.util.UUID.randomUUID().toString();
            user.setResetToken(resetToken);
            userRegistrationDao.UpdateUser(user);  // Save the token in the database

            // Send email with the reset link
            String resetLink = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() +
                    request.getContextPath() + "/reset-password?token=" + resetToken;
            System.out.println("resetLink generated is " + resetLink );
            
            EmailUtility.sendEmail(email, "Password Reset Request", 
                    "Click the link below to reset your password: \n" + resetLink);

            // Notify the user
            request.setAttribute("message", "A password reset link has been sent to your email.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
            dispatcher.forward(request, response);
        } else {
            request.setAttribute("error", "No user found with this email.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/forgot-password.jsp");
            dispatcher.forward(request, response);
        }
        } catch(Exception e){
        	e.printStackTrace();
            request.setAttribute("error", "Error sending email. Please try again.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/forgot-password.jsp");
            dispatcher.forward(request, response);
        }
    }
}

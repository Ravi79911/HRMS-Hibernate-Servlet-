package com.swati_hrms.web;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeeDependentDao;
import com.swati_hrms.dao.EmployeePersonalDetailsDao;
import com.swati_hrms.model.EmployeeDependent;
import com.swati_hrms.model.EmployeePersonalDetails;

@WebServlet("/addEmployeeDependent")
public class AddEmployeeDependent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AddEmployeeDependent() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String	idParam = request.getParameter("id");
		if(idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);
				
				if(employeeDetails != null) {
					request.setAttribute("employeeDetails", employeeDetails);
					request.getRequestDispatcher("Admin/addEmployeeDependent.jsp").forward(request, response);
				}else {
					request.setAttribute("errorMessage", "Employee not found with ID: " + id);
					response.sendRedirect("listRegisterMaster");
				}
			}catch(Exception e) {
				request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
				response.sendRedirect("listRegisterMaster");
			}
		}else {
			request.setAttribute("errorMessage", "Employee ID parameter is missing");
			response.sendRedirect("listRegisterMaster");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		if(idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				EmployeePersonalDetailsDao employeeDetailsDao = new EmployeePersonalDetailsDao();
				EmployeePersonalDetails employeeDetails = employeeDetailsDao.getEmployeeById(id);
				
				if(employeeDetails != null) {
					String dependentName = request.getParameter("dependent");
					String dependentRelation = request.getParameter("relation");
					String dobStr = request.getParameter("dob");
					
			 // Parse date of birth string to LocalDate
			        LocalDate dependentDob = LocalDate.parse(dobStr);
			        String dependentAadhaar = request.getParameter("aadhaar");
			        
			  // create employee dependent object      
			     EmployeeDependent empDept = new EmployeeDependent();
			     empDept.setEmployeePersonalDetails(employeeDetails);
			     empDept.setDependentName(dependentName);
			     empDept.setRelation(dependentRelation);
			     empDept.setDOB(dependentDob);
			     empDept.setAadhaarNo(dependentAadhaar);
			     empDept.setCreatedBy("Admin");
			     
			   //Save Employee Dependent   
			     EmployeeDependentDao empDeptDao = new EmployeeDependentDao();
			     empDeptDao.saveDependent(empDept);
			     
			     response.sendRedirect(request.getContextPath() + "/listRegisterMaster");
                 return; // Stop further execution
					
			  }else {
				  request.setAttribute("errorMessage", "Employee not found with ID: " + id);
				response.sendRedirect("listRegisterMaster");
			  }
			}catch(Exception e) {
				 request.setAttribute("errorMessage", "Error fetching employee: " + e.getMessage());
				 e.printStackTrace();
			}
		}else {
			request.setAttribute("errorMessage", "Employee ID parameter is missing");
			response.sendRedirect("listRegisterMaster");
		}
	}

}

package com.swati_hrms.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DesignationDao;
import com.swati_hrms.model.Designation;


@WebServlet("/listDesignationMaster")
public class ListDesignationMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public ListDesignationMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			DesignationDao designationDao = new DesignationDao();
			List<Designation> designation = designationDao.getAllDesignation();
			request.setAttribute("designations", designation);
			
			request.getRequestDispatcher("Admin/listDesignationMaster.jsp").forward(request, response);
		}catch(Exception e) {
			e.printStackTrace();
			response.getWriter().println("Error fetching designations: " + e.getMessage());
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

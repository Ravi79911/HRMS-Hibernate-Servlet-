package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.StreamsDao;
import com.swati_hrms.model.Streams;


@WebServlet("/deleteStreamsMaster")
public class DeleteStreamsMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteStreamsMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idStr = request.getParameter("id");
		
		if(idStr != null && !idStr.isEmpty()) {
			try {
				int id = Integer.parseInt(idStr);
				
				StreamsDao streamsDao = new StreamsDao();
				Streams streams = streamsDao.getStreamsById(id);
				
				if(streams != null) {
					// Mark the stream as suspended (inactive)
					streams.setSuspendedStatus(1);
					
					// Update the stream in the database
					streamsDao.updateStreams(streams);
					
					response.sendRedirect(request.getContextPath() + "/listStreamsMaster");
				}else {
					response.getWriter().println("Streams with ID " + id + " not found");
				}
			}catch(Exception e) {
				e.printStackTrace();
				response.getWriter().println("Error deleting stream: " + e.getMessage());
			}
			
		}else {
			response.getWriter().println("Stream ID parameter is missing or empty");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

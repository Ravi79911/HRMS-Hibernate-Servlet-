package com.swati_hrms.web;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.EmployeeBasicDao;
import com.swati_hrms.model.EmployeeBasic;

/**
 * Servlet implementation class EmployeeEdit
 */
@WebServlet("/editEmployeeBasic")
public class EmployeeBasicEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public EmployeeBasicEdit() {
        super();
        // TODO Auto-generated constructor stub
    }

    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String idStr = request.getParameter("id");
		if(idStr != null) {
			long id = Integer.parseInt(idStr);
			
			EmployeeBasicDao employeeBasicDAO = new EmployeeBasicDao();
			EmployeeBasic basic = employeeBasicDAO.getBasicById(id);
		
			
			        request.setAttribute("basics", basic);
			        
              
	            request.getRequestDispatcher("Admin/editEmployeeBasic.jsp").forward(request, response);
			 }
			 }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 long id = Long.parseLong(request.getParameter("id"));
	        String scaleName = request.getParameter("scaleName");
	        String scaleValue = request.getParameter("scaleValue");
	        String calculationType = request.getParameter("calculationType");

	        try {
	           
	        	 EmployeeBasicDao basicDAO=new EmployeeBasicDao();
	            EmployeeBasic basic = basicDAO.getBasicById(id);
	            basic.setScaleName(scaleName);
	            basic.setScaleValue(Double.parseDouble(scaleValue));
	            basic.setCalculationType(calculationType);
	            basic.setUpdatedDate(new Date());
	            basic.setUpdatedBy("Admin");
	            basicDAO.updateBasic(basic);
	       
	        } catch (Exception e) {
	           
	            e.printStackTrace();
	        } 

	        response.sendRedirect(request.getContextPath() + "/employeeBasicList?success=true");
	    }
	}
	

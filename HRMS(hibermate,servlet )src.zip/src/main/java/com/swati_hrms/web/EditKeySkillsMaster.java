package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.KeySkillsDao;
import com.swati_hrms.model.KeySkills;

@WebServlet("/editKeySkillsMaster")
public class EditKeySkillsMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public EditKeySkillsMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				KeySkillsDao keySkillsDao = new KeySkillsDao();
				KeySkills skills = keySkillsDao.getKeySkillsById(id);

				if (skills != null) {
					request.setAttribute("skills", skills);
					request.getRequestDispatcher("Admin/editKeySkillsMaster.jsp").forward(request, response);
				} else {
					request.setAttribute("errorMessage", "Skill not found with ID: " + id);
					response.sendRedirect("listKeySkillsMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid skill ID format");
				response.sendRedirect("listKeySkillsMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error fetching skill: " + e.getMessage());
				response.sendRedirect("listKeySkillsMaster");
			}
		} else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "Skill ID parameter is missing");
			response.sendRedirect("listKeySkillsMaster");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String idParam = request.getParameter("id");
		String skillName = request.getParameter("skill");
		if (idParam != null && !idParam.isEmpty()) {
			try {
				int id = Integer.parseInt(idParam);
				KeySkillsDao keySkillsDao = new KeySkillsDao();
				KeySkills skills = keySkillsDao.getKeySkillsById(id);

				if (skills != null) {
					skills.setSkillName(skillName);
					;
					keySkillsDao.updateKeySkills(skills);
					response.sendRedirect("listKeySkillsMaster");
				} else {
					request.setAttribute("errorMessage", "Skill not found with ID: " + id);
					response.sendRedirect("listKeySkillsMaster");
				}
			} catch (NumberFormatException e) {
				request.setAttribute("errorMessage", "Invalid skill ID format");
				response.sendRedirect("listKeySkillsMaster");
			} catch (Exception e) {
				request.setAttribute("errorMessage", "Error fetching skill: " + e.getMessage());
				response.sendRedirect("listKeySkillsMaster");
			}
		} else {
			// Handle case where no ID parameter is provided
			request.setAttribute("errorMessage", "Skill ID parameter is missing");
			response.sendRedirect("listKeySkillsMaster");
		}
	}

}

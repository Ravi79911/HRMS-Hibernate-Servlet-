package com.swati_hrms.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.swati_hrms.dao.EmployeeBasicDao;
import com.swati_hrms.model.EmployeeBasic;
import com.swati_hrms.util.HibernateUtil;


@WebServlet("/addEmpBasic")
public class AddEmployeeBasic extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public AddEmployeeBasic() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String[] scaleNames = request.getParameterValues("scaleName");
        String[] scaleValues = request.getParameterValues("scaleValue");
        String[] calculationTypes = request.getParameterValues("calculationType");

        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        try {
            List<EmployeeBasic> basicList = new ArrayList<>();
            for (int i = 0; i < scaleNames.length; i++) {
                EmployeeBasic basic = new EmployeeBasic();
                basic.setScaleName(scaleNames[i]);
                basic.setScaleValue(Double.parseDouble(scaleValues[i]));
                basic.setCalculationType(calculationTypes[i]);
                basic.setCreatedBy("Admin");
                basic.setCreatedDate(new Date());
                basicList.add(basic);
                session.save(basic);
            }
            tx.commit();
            response.sendRedirect(request.getContextPath() + "/employeeBasicList?success=true");
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
		
		
		
		
	}
	



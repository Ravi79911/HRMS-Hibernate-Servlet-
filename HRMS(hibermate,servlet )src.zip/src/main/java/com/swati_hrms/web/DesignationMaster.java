package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.DesignationDao;
import com.swati_hrms.model.Designation;


@WebServlet("/designationMaster")
public class DesignationMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DesignationMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String designationName = request.getParameter("designation");
		
		if(designationName != null && !designationName.isEmpty()) {
			try {
				Designation designation = new Designation();
				designation.setDesignation(designationName);
				designation.setCreatedBy("Admin"); //to be replaced with username
				
				DesignationDao designationDao = new DesignationDao();
				designationDao.saveDesignation(designation);
				
				response.sendRedirect(request.getContextPath() + "/listDesignationMaster");
                return; // Stop further execution
				
			}catch(Exception e) {
				response.getWriter().println("Error saving designation: " + e.getMessage());
			}
		}else {
			response.getWriter().println("Designation name parameter is missing or empty");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

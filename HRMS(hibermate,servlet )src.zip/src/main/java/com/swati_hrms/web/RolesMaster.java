package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.RolesDao;
import com.swati_hrms.model.Roles;


@WebServlet("/rolesMaster")
public class RolesMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public RolesMaster() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String roleName = request.getParameter("roleName");
		if(roleName != null && !roleName.isEmpty()) {
			try {
				Roles roles = new Roles();
				roles.setRoleName(roleName);
				roles.setCreatedBy("Admin");
				
				
				RolesDao rolesDao = new RolesDao();
				rolesDao.saveRole(roles);
				
				 response.sendRedirect(request.getContextPath() + "/listRolesMaster");
	             return; // Stop further execution
			}catch(Exception e) {
				response.getWriter().println("Error saving role: " + e.getMessage());
			}
			
		}else {
			response.getWriter().println("Role name parameter is missing or empty");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

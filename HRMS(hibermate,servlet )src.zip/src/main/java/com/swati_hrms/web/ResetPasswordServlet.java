package com.swati_hrms.web;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.swati_hrms.dao.UserRegistrationDao;
import com.swati_hrms.model.UserRegistration;

@WebServlet("/resetPassword")
public class ResetPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private UserRegistrationDao userRegistrationDao;

    public void init() {
        userRegistrationDao = new UserRegistrationDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String token = request.getParameter("token");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        if (newPassword.equals(confirmPassword)) {
            UserRegistration user = userRegistrationDao.findUserByToken(token);

            if (user != null) {
                user.setPassword(newPassword);  // You should hash the password before saving it
                user.setResetToken(null);  // Clear the token after password reset
                userRegistrationDao.UpdateUser(user);

                request.setAttribute("message", "Password successfully reset.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
                dispatcher.forward(request, response);
            } else {
                request.setAttribute("error", "Invalid reset token.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/reset-password.jsp");
                dispatcher.forward(request, response);
            }
        } else {
            request.setAttribute("error", "Passwords do not match.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("Admin/reset-password.jsp");
            dispatcher.forward(request, response);
        }
    }
}
